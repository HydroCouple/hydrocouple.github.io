// The previous edition's figure sources and captions are preserved in baseline-24h.zip.
import './study/plot-hydrographs.mjs';
import {terrainViews} from './terrain.mjs';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
const here=path.dirname(fileURLToPath(import.meta.url));
const shapes=terrainViews({areaAcres:4,ratio:1,slopePercent:2});
const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="460" viewBox="0 0 1080 460" role="img" aria-labelledby="title">
  <title id="title">Open-book and teardrop drainage surfaces</title>
  <rect width="1080" height="460" fill="white"/>
  <g font-family="Arial, sans-serif" fill="#173c3a" text-anchor="middle">
    <text x="270" y="55" font-size="34" font-weight="bold">Open book</text>
    <text x="810" y="55" font-size="34" font-weight="bold">Teardrop</text>
    <g transform="translate(0,72)">${shapes.book}</g>
    <g transform="translate(540,72)">${shapes.drop}</g>
    <text x="540" y="430" font-size="22">4 acres each · width/length 1 · side slope 2% · vertical exaggeration ×8</text>
  </g></svg>`;
fs.writeFileSync(path.join(here,'figures/drainage-shapes.svg'),svg);
execFileSync('rsvg-convert',['--width','1800','figures/drainage-shapes.svg','--output','figures/drainage-shapes.png'],{cwd:here});
const temp=path.join(here,'linkedin-figures-new.zip');
fs.rmSync(temp,{force:true});
execFileSync('zip',['-q',temp,'figures/drainage-shapes.png','figures/drainage-shapes.svg','figures/storm-matrix-hydrographs.png','figures/storm-matrix-hydrographs.svg','linkedin-article.md'],{cwd:here});
fs.renameSync(temp,path.join(here,'linkedin-figures.zip'));
