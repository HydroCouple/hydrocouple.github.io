// Run the browser bundle against every slider stop, including its offline download paths.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {areas,ratios,periods,slopes,scenarios,methods,inputFor} from './study/design.mjs';

const here=path.dirname(fileURLToPath(import.meta.url)), read=f=>fs.readFileSync(path.join(here,f),'utf8');
const index=read('index.html');
const offline=read('report.html');
for(const page of [index,read('../../articles.html'),offline]) {
  assert.equal((page.match(/id="runoff-explorer"/g)||[]).length,1);
  for(const id of ['storm','area','ratio','slope','metrics','volumes','refinement','status','chart'])
    assert.ok(page.includes('id="rt-'+id+'"'));
}
for(const file of ['study/data.js','explorer.js']) {
  assert(index.includes('src="'+file+'"'));
  assert(offline.includes(read(file)));
}
const nodes=new Map();
function node(id) {
  if(!nodes.has(id))nodes.set(id,{
    value:0, dataset:{},setAttribute(k,v){this[k]=v;},
    addEventListener(k,fn){this[k]=fn;},click(){this.onclick?.();}
  });
  return nodes.get(id);
}
const root={querySelector:s=>node(s.slice(4)),querySelectorAll:s=>s==='[data-view]'?['flow','volume','unit'].map(view=>{
  const b=node('view-'+view);b.dataset.view=view;return b;}):[]};
let blob,link;
const document={getElementById:()=>root,createElement:()=>link=node('download')};
const context=vm.createContext({document,Blob,URL:{createObjectURL(b){blob=b;return 'blob:test';},revokeObjectURL(){}},setTimeout(){}});
vm.runInContext(read('study/data.js'),context);vm.runInContext(read('explorer.js'),context);
for(const s of scenarios) {
  for(const [id,values,value] of [['area',areas,s.areaAcres],['ratio',ratios,s.ratio],['storm',periods,s.period],['slope',slopes,s.slopePercent]])
    node(id).value=values.indexOf(value);
  node('storm').input();
  assert(node('status').textContent.includes(s.period+'-year storm'));
  for(const view of ['flow','unit','volume']) {
    node('view-'+view).click();
    for(let zoom=0;zoom<2;zoom++) {
      node('zoom').click();
      const svg=node('chart').innerHTML;
      assert.doesNotMatch(svg,/NaN|Infinity/);
      const bars=[...svg.matchAll(/<rect [^>]*y="([\d.]+)" width="[\d.]+" height="([\d.]+)"[^>]*><title>Minutes/g)];
      const curves=[...svg.matchAll(/<path d="([^"]+)" clip-path=/g)];
      assert(bars.length>0);assert.equal(curves.length,3);
      const lowestBar=Math.max(...bars.map(([,y,h])=>Number(y)+Number(h)));
      const highestFlow=Math.min(...curves.flatMap(([,d])=>Array.from(d.matchAll(/,([\d.]+)/g),m=>Number(m[1]))));
      assert(lowestBar+5 < highestFlow,'Rain bars and flow curves must occupy separate panels');
    }
  }
  assert.equal((node('metrics').innerHTML.match(/<tr>/g)||[]).length,3);
  assert.equal((node('volumes').innerHTML.match(/<tr>/g)||[]).length,3);
  for (const m of methods) {
    node('model').value=m.id;node('inp').click();
    const input=await blob.text();
    assert.equal(input,inputFor(s,m.id));
    const result=JSON.parse(read('study/runs/'+s.id+'/'+m.id+'.json'));
    assert.equal(createHash('sha256').update(input).digest('hex'),result.identity.input);
    node('rpt').click();assert.equal(await blob.text(),read('study/runs/'+s.id+'/'+m.id+'.rpt'));
  }
  node('csv').click();assert.equal(link.download,s.id+'.csv');
  assert.equal((await blob.text()).trim().split('\n').length,482);
}
console.log('Verified all 54 slider selections, 162 input/report pairs, 54 CSV downloads, plot modes, embedded offline data and both website entry points.');
