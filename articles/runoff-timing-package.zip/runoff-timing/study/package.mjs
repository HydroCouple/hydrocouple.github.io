// Build the offline browser asset only from complete, verified native outputs.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {scenarios, methods, hours, depths, inputFor, blocksPercent} from './design.mjs';
import {ACRE_M2} from '../model.mjs';
import {parseInput} from '../package-matrix.mjs';

const root = fileURLToPath(new URL('./',import.meta.url));
const read = file => fs.readFileSync(root+file,'utf8');
const sha = text => createHash('sha256').update(text).digest('hex');
const engines=new Set(), runners=new Set();
const near=(value,expected,tolerance,label)=>assert.ok(Math.abs(value-expected)<=tolerance,
  `${label}: measured ${value}, expected ${expected} within ${tolerance}`);
const quantiles=JSON.parse(read('../evidence/atlas14-nyc-pds.txt').match(/^quantiles = (.*);/m)[1].replaceAll("'",'"'));
for(const [period,column] of [[2,1],[25,4],[100,6]]) assert.equal(depths[period],Number(quantiles[5][column]));
assert.equal(blocksPercent.reduce((a,b)=>a+b),100);

function load(s,method,refinement=1) {
  const stem='runs/'+s.id+(refinement===2?'-fine':'')+'/'+method;
  const r=JSON.parse(read(stem+'.json')), report=read(stem+'.rpt');
  const input=inputFor(s,method,refinement), sections=parseInput(input);
  assert.equal(r.identity.input,sha(input)); assert.equal(r.identity.report,sha(report));
  engines.add(r.identity.engine); runners.add(r.identity.runner);
  assert.equal(r.id,method); assert.doesNotMatch(report,/ERROR\s+\d+/);
  assert.ok(r.continuity_errors_percent.length && r.continuity_errors_percent.every(x=>Math.abs(x)<0.1));
  const area=s.areaAcres*ACRE_M2, rain=area*depths[s.period]*0.0254;
  near(r.totalRain,rain,rain*1e-10,'expected rain');
  near(sections.TIMESERIES.reduce((a,row)=>a+Number(row[3])/12,0),depths[s.period]*25.4,1e-8,'input rain mm');
  assert.equal(r.samples.length,60*hours+1);
  let volume=0, peak=0, peakTime=0;
  for(const [i,[t,q,v]] of r.samples.entries()) {
    assert.equal(t,i*60); assert.ok(q>=0 && Number.isFinite(q));
    if(q>peak){peak=q;peakTime=t;}
    volume+=q*60;
    near(volume,v,rain*1e-8,'integrated flow');
  }
  assert.equal(r.peak,peak); assert.equal(r.peakTime,peakTime);
  near(volume,r.delivered,rain*1e-8,'outlet ledger');
  let storage=null, closure=null;
  if (method==='lumped') {
    const precip=report.match(/Total Precipitation[^\n]*\s([\d.]+)\s*\n/);
    near(Number(precip[1]),depths[s.period]*25.4,0.00051,'reported precipitation mm');
    assert.match(report,/Flooding Loss\s*\.+\s*0\.000\s+0\.000/);
    near(+sections.SUBCATCHMENTS[0][6],s.slopePercent,1e-10,'reservoir slope');
  } else {
    const v=sections['2D_VERTICES'].map(row=>row.map(Number));
    const triangles=sections['2D_TRIANGLES'].map(row=>row.slice(0,3).map(Number));
    let meshArea=0,opening=0;
    for(const [x,y,z] of v) near(z,(Math.abs(x)+y/4)*s.slopePercent/100,1e-10,'bed elevation');
    for(const tri of triangles) {
      const [a,b,c]=tri.map(i=>v[i]);
      const signed=((b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]))/2;
      assert(signed>0); meshArea+=signed;
    }
    for (const [cell,edge,,grade] of sections['2D_BOUNDARY_CONDITIONS']) {
      const tri=triangles[+cell], a=v[tri[(+edge+1)%3]], b=v[tri[(+edge+2)%3]];
      assert.equal(a[1],0); assert.equal(b[1],0); assert.equal(+grade,s.slopePercent/400);
      opening+=Math.abs(a[0]-b[0]);
    }
    const toe=v.filter(p=>p[1]===0).map(p=>p[0]);
    near(opening,(Math.max(...toe)-Math.min(...toe))/4,1e-9,'outlet width');
    near(meshArea,area,area*1e-10,'mesh area');
    near(r.balance.rainfallIn,rain,rain*1e-8,'native rain');
    storage=r.balance.finalStorage;
    closure=100*(r.balance.rainfallIn-r.delivered-storage)/rain;
    near(r.balance.boundaryOut,r.delivered,rain*1e-10,'boundary ledger');
    near(closure,0,0.01,'2D rain minus outflow and storage (% of rain)');
  }
  return {peak:r.peak, peakTime:r.peakTime, centroid:r.centroid, rain, volume:r.delivered,
    atRainEnd:r.samples[60][2], storage, closure, report,
    samples:r.samples.map(([,q,v])=>[+q.toPrecision(10),+v.toPrecision(10)])};
}
const rows=scenarios.map(s=>({...s,runs:methods.map(m=>load(s,m.id))}));
const fine=[];
for(const id of ['a0.1-r0.25-s2-y25','a4-r4-s2-y25','a64-r0.25-s2-y25','a64-r0.25-s0.5-y25']) {
  const s=rows.find(r=>r.id===id);
  for(const [i,m] of methods.entries()) if(i>0) {
    const r=load(s,m.id,2), base=s.runs[i];
    const change={method:m.id,peakChangePct:100*(r.peak/base.peak-1),timeChangeMin:(r.peakTime-base.peakTime)/60};
    (s.refinement ??= []).push(change);
    fine.push({id,...change});
  }
}
assert.equal(engines.size,1);assert.equal(runners.size,1);
const validation={scenarios:rows.length,nativeRuns:rows.length*methods.length,refinementRuns:fine.length,
  engineSha256:[...engines][0],runnerSha256:[...runners][0],fine,
  maxAbsoluteClosurePercent:Math.max(...rows.flatMap(s=>s.runs.slice(1).map(r=>Math.abs(r.closure))))};
fs.writeFileSync(root+'validation.json',JSON.stringify(validation,null,2)+'\n');
const csv=['scenario,area_acres,width_to_length,side_slope_pct,return_period_years,model,peak_cfs,peak_min,peak_diff_pct,time_diff_min,rain_m3,outlet_8h_m3,volume_diff_pct,final_2d_storage_m3,closure_pct_of_rain'];
for(const s of rows) for(const [i,r] of s.runs.entries()) {
  const b=s.runs[0];
  csv.push([s.id,s.areaAcres,s.ratio,s.slopePercent,s.period,methods[i].id,r.peak*35.3146667,r.peakTime/60,
    100*(r.peak/b.peak-1),(r.peakTime-b.peakTime)/60,r.rain,r.volume,100*(r.volume/b.volume-1),r.storage,r.closure].join(','));
}
fs.writeFileSync(root+'summary.csv',csv.join('\n')+'\n');
fs.writeFileSync(root+'data.js','globalThis.RUNOFF_STUDY = '+JSON.stringify(rows).replaceAll('<','\\u003c')+';\n');
console.log(validation);
