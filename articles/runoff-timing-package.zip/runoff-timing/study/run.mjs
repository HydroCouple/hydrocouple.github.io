// Run the factorial design, retaining native ledgers, reports and input identities.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {createHash} from 'node:crypto';
import {scenarios, methods, depths, hours, inputFor} from './design.mjs';

const [engine,runner,workers='4',filter,refine='1'] = process.argv.slice(2);
if (!engine || !runner || !Number.isInteger(+workers) || +workers<1 || ![1,2].includes(+refine))
  throw Error('Usage: node study/run.mjs ENGINE RUNNER [workers] [scenario-id] [refinement 1|2]');
const root=fileURLToPath(new URL('./runs/',import.meta.url));
const sha = data => createHash('sha256').update(data).digest('hex');
const engineHash=sha(fs.readFileSync(engine)), runnerHash=sha(fs.readFileSync(runner));
const jobs=scenarios.slice().reverse().filter(s=>!filter || s.id===filter)
  .flatMap(s=>methods.filter(m=>+refine===1 || m.id!=='lumped').map(m=>({s,method:m.id})));
if (!jobs.length) throw Error('No matching scenarios');
async function run({s,method}) {
  const dir=path.join(root,s.id+(+refine===2?'-fine':''));
  fs.mkdirSync(dir,{recursive:true});
  const dest=path.join(dir,method+'.json'),report=path.join(dir,method+'.rpt');
  const input=inputFor(s,method,+refine);
  const identity={engine:engineHash, runner:runnerHash, input:sha(input)};
  if (fs.existsSync(dest) && fs.existsSync(report)) {
    const old=JSON.parse(fs.readFileSync(dest));
    if(Object.keys(identity).every(k=>identity[k]===old.identity[k]) &&
       old.identity.report===sha(fs.readFileSync(report)) && old.samples.length===hours*60+1) return;
  }
  const lock=dest+'.lock';
  const lockFd=fs.openSync(lock,'wx');
  fs.writeFileSync(lockFd,String(process.pid));
  fs.closeSync(lockFd);
  let temp;
  try {
    temp=fs.mkdtempSync(path.join(os.tmpdir(),'runoff-case-'));
    fs.writeFileSync(path.join(temp,'model.inp'),input);
    await promisify(execFile)(path.resolve(runner),[path.resolve(engine),'model.inp','model.rpt','result.json',
      method,String(s.areaAcres),String(depths[s.period]),String(hours)],{cwd:temp,env:{...process.env,OMP_NUM_THREADS:'1'}});
    const result=JSON.parse(fs.readFileSync(path.join(temp,'result.json')));
    const rpt=fs.readFileSync(path.join(temp,'model.rpt'));
    result.identity={...identity,report:sha(rpt)};
    fs.writeFileSync(report+'.'+process.pid+'.tmp',rpt);
    fs.renameSync(report+'.'+process.pid+'.tmp',report);
    fs.writeFileSync(dest+'.'+process.pid+'.tmp',JSON.stringify(result));
    fs.renameSync(dest+'.'+process.pid+'.tmp',dest);
    console.log(s.id,method,result.wall_seconds.toFixed(1)+'s');
  } finally {
    if(temp) fs.rmSync(temp,{recursive:true,force:true});
    fs.unlinkSync(lock);
  }
}
async function worker() {
  while (jobs.length) {
    const job=jobs.shift();
    try {await run(job);} catch(e) {console.error(job.s.id,job.method,e.message); process.exitCode=1;}
  }
}
await Promise.all(Array.from({length:+workers},worker));
