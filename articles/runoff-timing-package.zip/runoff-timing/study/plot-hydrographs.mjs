// Build the article figure from matched, one-minute native outlet records.
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {readFileSync, writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {rainTicks, rainBars, rainInk} from './hyetograph.mjs';
import {depths, hours, inputFor, methods, scenarios} from './design.mjs';

const areas = [0.1, 64];
const period = 25;
const ratio = 0.25;
const slopePercent = 2;
const cfsPerCms = 1 / 0.028316846592;
const endMinute = 120;
const sha = bytes => createHash('sha256').update(bytes).digest('hex');

function loadPanel(areaAcres) {
  const scenario = scenarios.find(s => s.areaAcres === areaAcres && s.period === period
    && s.ratio === ratio && s.slopePercent === slopePercent);
  assert(scenario, 'Selected case is missing from the design');
  const series = methods.map(method => {
    const base = new URL(`./runs/${scenario.id}/`, import.meta.url);
    const run = JSON.parse(readFileSync(new URL(method.id + '.json', base)));
    assert.equal(run.id, method.id);
    assert.equal(run.identity.input, sha(inputFor(scenario, method.id)));
    assert.equal(run.identity.report, sha(readFileSync(new URL(method.id + '.rpt', base))));
    assert.equal(run.samples.length, hours * 60 + 1);
    assert(run.samples.every(([time, flow], i) => time === i*60 && Number.isFinite(flow) && flow >= 0));
    const crest = run.samples.reduce((high, p) => p[1] > high[1] ? p : high);
    assert.equal(run.peak, crest[1]);
    assert.equal(run.peakTime, crest[0]);
    assert(crest[0] <= endMinute * 60, 'Extend plot to include the peak');
    return {...method, areaAcres, run};
  });
  return {areaAcres, series};
}

const panels = areas.map(loadPanel);
const maxPeak = Math.max(...panels.flatMap(panel =>
  panel.series.map(s => s.run.peak * cfsPerCms / panel.areaAcres)));
const step = Math.ceil(maxPeak / 5);
const yMax = step * 5;
const ink = '#193d3a', muted = '#47625d', grid = '#cfded9';
const dashes = {lumped: '12 7', book: '', drop: '2 7'};
const labels = {lumped: 'Lumped', book: 'Open book', drop: 'Teardrop'};
const output = new URL('../figures/storm-matrix-hydrographs.svg', import.meta.url);
const png = new URL('../figures/storm-matrix-hydrographs.png', import.meta.url);
const width = 1200, height = 1360;

function label(x, y, value, size, anchor='start', color=ink, weight=400) {
  return `<text x="${x}" y="${y}" fill="${color}" text-anchor="${anchor}" font-weight="${weight}" font-size="${size}">${value}</text>`;
}
function line(x1, y1, x2, y2, color, strokeWidth, dash='') {
  return `<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${color}" stroke-width="${strokeWidth}" stroke-dasharray="${dash || 'none'}"/>`;
}
function drawPanel({areaAcres, series}, offset) {
  const left = 85, right = 650;
  const rainTop = offset + 56, rainBottom = rainTop + 116;
  const top = rainBottom + 59, bottom = top + 206;
  const x = seconds => left + seconds/(endMinute*60)*(right-left);
  const y = flowPerAcre => bottom - flowPerAcre/yMax*(bottom-top);
  const svg = [label(50, offset, `${areaAcres}-acre sewershed`, 36, 'start', ink, 700)];
  const rainY = intensity => rainTop + intensity/rainTicks.at(-1)*(rainBottom-rainTop);
  svg.push(rainBars(period, minute=>x(minute*60), rainY, 0, endMinute));
  svg.push(line(left,rainTop,right,rainTop,rainInk,1.5), line(right,rainTop,right,rainBottom,rainInk,1.5));
  for (const tick of rainTicks) {
    svg.push(line(right,rainY(tick),right+5,rainY(tick),rainInk,1.5),
      label(right+9,rainY(tick)+7,tick,21,'start',rainInk));
  }
  svg.push(label(right,rainTop-14,'Rainfall (in/h)',23,'end',rainInk));
  for (let tick=0; tick<=yMax; tick+=step) {
    svg.push(line(left,y(tick),right,y(tick),grid,1.5), label(left-12,y(tick)+7,tick,22,'end',muted));
  }
  svg.push(line(left,top,left,bottom,muted,1.5), line(left,bottom,right,bottom,muted,1.5));
  for (let tick=0; tick<=endMinute; tick+=30) {
    svg.push(line(x(tick*60),bottom,x(tick*60),bottom+7,muted,1.5),
      label(x(tick*60),bottom+32,tick,22,'middle',muted));
  }
  svg.push(label(left,top-14,'Outlet flow (ft³/s per acre)',23,'start',muted));
  svg.push(label((left+right)/2,bottom+68,'Minutes from storm start',25,'middle',ink));
  svg.push(label(720,top-14,'Model',23,'start',muted),label(1037,top-14,'Peak',23,'end',muted),
    label(1148,top-14,'Time',23,'end',muted));
  svg.push(label(1037,top+17,'(ft³/s)',22,'end',muted),label(1148,top+17,'(min)',22,'end',muted));
  // Draw the solid line first so both styles remain visible when hydrographs coincide.
  const plotOrder = ['book', 'lumped', 'drop'];
  for (const id of plotOrder) {
    const s = series.find(method => method.id === id);
    const points = s.run.samples.slice(0,endMinute+1).map(([time, flow], i) =>
      `${i===0?'M':'L'}${x(time).toFixed(2)},${y(flow*cfsPerCms/areaAcres).toFixed(2)}`).join(' ');
    svg.push(`<path d="${points}" fill="none" stroke="${s.color}" stroke-width="4" stroke-dasharray="${dashes[s.id] || 'none'}"/>`);
  }
  for (const [index, s] of series.entries()) {
    const row = top + 63 + index*50;
    const peakCfs = s.run.peak * cfsPerCms;
    svg.push(line(720,row-8,752,row-8,s.color,4,dashes[s.id]), label(765,row,labels[s.id],26),
      label(1037,row,peakCfs.toFixed(areaAcres<1 ? 3 : 1),26,'end',ink,700),
      label(1148,row,s.run.peakTime/60,26,'end',ink,700));
  }
  return svg.join('\n');
}

const description = panels.map(p => `${p.areaAcres} acres: ` + p.series.map(s =>
  `${labels[s.id]} ${(s.run.peak*cfsPerCms).toPrecision(4)} cubic feet per second at minute ${s.run.peakTime/60}`).join(', ')).join('. ');
const svg = [
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}" role="img" aria-labelledby="title description">`,
  '<title id="title">Outlet hydrographs for two sewershed sizes</title>',
  `<desc id="description">Flow per acre over the first two hours, using the same axes. Rainfall intensity increases downward in the upper panel of each pair. ${description}.</desc>`,
  `<rect width="${width}" height="${height}" fill="white"/>`,
  '<g font-family="Arial, Helvetica, sans-serif" stroke-linecap="round" stroke-linejoin="round">',
  label(50,70,'How basin size changes the outlet peak',52,'start',ink,700),
  label(50,116,`NYC ${period}-year, 1-hour storm · ${depths[period].toFixed(2)} in · width/length ${ratio} · side slope ${slopePercent}%`,28,'start',muted),
  line(50,152,1150,152,grid,2),
  drawPanel(panels[0],211),
  line(50,750,1150,750,grid,2),
  drawPanel(panels[1],807),
  label(50,1344,'Blue bars show five-minute rain intensity. Curves show one-minute mean outlet flows.',24,'start',muted),
  '</g></svg>'
].join('\n');
writeFileSync(output, svg);
execFileSync('rsvg-convert', ['--width','1800',fileURLToPath(output),'--output',fileURLToPath(png)]);
console.log(description);
