import {buildModel, geometry, halfWidth, bed, STATIONS, METHODS} from '../model.mjs';

export const areas = [0.1, 4, 64];
export const ratios = [0.25, 1, 4];
export const slopes = [0.5, 2];
export const periods = [2, 25, 100];
// NOAA Atlas 14 Vol. 10, NYC PDS 60-minute point estimates (archived in evidence/).
export const depths = {2: 1.68, 25: 2.89, 100: 3.60};
export const blocksPercent = [2, 3, 4, 6, 10, 20, 25, 12, 8, 5, 3, 2];
export const hours = 8;
export const methods = METHODS;
export const scenarios = [];
for (const areaAcres of areas) for (const ratio of ratios)
  for (const slopePercent of slopes) for (const period of periods) {
    scenarios.push({id: `a${areaAcres}-r${ratio}-s${slopePercent}-y${period}`,
      areaAcres, ratio, slopePercent, period});
  }

function surface(settings, shape, refinement) {
  const {width, length} = geometry(settings, shape);
  const stations = shape === 'drop' ? STATIONS : Array.from({length: 9}, (_, j) => j / 8);
  const lines = stations.slice(1).flatMap((end, j) =>
    Array.from({length: refinement}, (_, i) => stations[j] + (end-stations[j])*i/refinement));
  lines.push(1);
  const columns = 8 * refinement;
  const vertices = [], triangles = [];
  for (const f of lines) {
    for (let i = 0; i <= columns; i++) {
      const x = halfWidth(f, width, shape) * (2*i/columns - 1), y = f*length;
      vertices.push([x,y,bed(x,y,settings.slopePercent/100)]);
    }
  }
  for (let j=0; j<lines.length-1; j++) for (let i=0; i<columns; i++) {
    const a=j*(columns+1)+i, b=a+1, c=b+columns+1, d=c-1;
    // Mirror diagonals about the fold to preserve the symmetry of both wings.
    if (i<columns/2) triangles.push([a,b,c],[a,c,d]);
    else triangles.push([a,b,d],[b,c,d]);
  }
  return {vertices,triangles};
}
export function inputFor(settings, method, refinement=1) {
  const storm = {blocksPercent, frequency:{return_period_years:settings.period, depth_inches:depths[settings.period]}};
  return buildModel(settings, method, storm, method==='lumped' ? null : surface(settings,method,refinement));
}
