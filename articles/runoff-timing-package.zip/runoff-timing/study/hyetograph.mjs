import {blocksPercent, depths} from './design.mjs';

// Use the same rainfall scale across storms, zoom levels and basin geometries.
export const rainTicks = [0, 3, 6, 9, 12];
export const rainInk = '#286889';
export const rainFill = '#b6daea';
export function rainBars(period, xMinute, yIntensity, fromMinute, toMinute) {
  return blocksPercent.map((percent, i) => {
    const start = Math.max(i*5, fromMinute), end = Math.min((i+1)*5, toMinute);
    if (end <= start) return '';
    const intensity = depths[period] * (percent/100) / (5/60);
    const top = yIntensity(0);
    return `<rect x="${xMinute(start)}" y="${top}" width="${xMinute(end)-xMinute(start)}" height="${yIntensity(intensity)-top}" fill="${rainFill}" stroke="#71a7bf" stroke-width="0.7"><title>Minutes ${i*5}–${(i+1)*5}: ${intensity.toFixed(2)} in/h</title></rect>`;
  }).join('');
}
