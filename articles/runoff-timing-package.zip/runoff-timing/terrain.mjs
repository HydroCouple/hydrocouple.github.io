import {geometry, halfWidth, bed, STATIONS} from './model.mjs';

// Fit both surfaces using one scale so that the equal-area footprints remain comparable.
export function terrainViews(settings) {
  const project = (x, y) => [
    0.88*x + 0.52*y,
    0.26*x - 0.64*y - 8*bed(x,y,settings.slopePercent/100),
  ];
  const surfaces = ['book','drop'].map(shape => {
    const g = geometry(settings,shape);
    const vertices = STATIONS.flatMap(f => [-1,0,1].map(sign =>
      project(sign*halfWidth(f,g.width,shape),f*g.length)));
    const xs = vertices.map(p=>p[0]), ys = vertices.map(p=>p[1]);
    const left=Math.min(...xs), top=Math.min(...ys);
    const width=Math.max(...xs)-left, height=Math.max(...ys)-top;
    return {shape,g,width,height,centerX:left+width/2,centerY:top+height/2};
  });
  const scale=Math.min(...surfaces.flatMap(s=>[450/s.width,225/s.height]));
  return Object.fromEntries(surfaces.map(({shape,g,centerX,centerY}) => {
    const toSvg = (x,y) => {
      const [u,v]=project(x,y);
      return [270+scale*(u-centerX),145+scale*(v-centerY)];
    };
    return [shape,drawTerrain(g,shape,toSvg)];
  }));
}

function drawTerrain(g, shape, project) {
  const pt = (x, y) =>
    project(x, y)
      .map((v) => v.toFixed(1))
      .join(",");
  const marker = `arrow-${shape}`;
  let html = `<defs><marker id="${marker}" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0 0 L5 2.5 L0 5 Z" fill="#087f78"/></marker></defs>`;
  const levels = shape === "drop" ? STATIONS : Array.from({length:13}, (_,i) => i/12);
  for (let j = levels.length - 2; j >= 0; j--) {
    const y0 = levels[j] * g.length,
      y1 = levels[j+1] * g.length,
      h0 = halfWidth(levels[j], g.width, shape),
      h1 = halfWidth(levels[j+1], g.width, shape);
    for (const sign of [-1, 1])
      html += `<polygon points="${pt(0, y0)} ${pt(sign * h0, y0)} ${pt(sign * h1, y1)} ${pt(0, y1)}" fill="${sign < 0 ? "#dce9d9" : "#c4d9cc"}" stroke="#a5bfb0" stroke-width=".6"/>`;
  }
  html += `<path d="M${pt(0, g.length)} L${pt(0, 0)}" stroke="#306f68" stroke-width="3.2"/>`;
  for (const f of [0.3, 0.58, 0.84]) {
    const y = f * g.length,
      h = halfWidth(f, g.width, shape);
    for (const sign of [-1, 1])
      html += `<path d="M${pt(sign * h * 0.82, y)} L${pt(sign * h * 0.08, y - g.length * 0.06)}" fill="none" stroke="#087f78" stroke-width="1.8" marker-end="url(#${marker})"/>`;
  }
  html += `<path d="M${pt(0, g.length * 0.4)} L${pt(0, g.length * 0.08)}" stroke="#087f78" stroke-width="2.6" marker-end="url(#${marker})"/>`;
  const outletHalf = halfWidth(0,g.width,shape)/4;
  html += `<path d="M${pt(-outletHalf,0)} L${pt(outletHalf,0)}" stroke="#173c3a" stroke-width="5" stroke-linecap="round"/>`;
  const outlet = project(0, 0);
  html += `<circle cx="${outlet[0]}" cy="${outlet[1]}" r="4" fill="#173c3a"/>`;
  return html;
}
