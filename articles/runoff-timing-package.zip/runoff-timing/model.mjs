export const ACRE_M2 = 4046.8564224;
export const CONFIG = Object.freeze({
  sideSlope: 0.02,
  centerSlope: 0.005,
  roughness: 0.03,
  hours: 48,
});
export const METHODS = [
  { id: "lumped", label: "SWMM subcatchment (lumped)", color: "#9c6c28" },
  { id: "book", label: "OpenSWMM 2D · open book", color: "#087f78" },
  { id: "drop", label: "OpenSWMM 2D · teardrop", color: "#ad4561" },
];
export const STATIONS = [0, 0.08, 0.2, 0.35, 0.5, 0.64, 0.76, 0.86, 0.94, 0.98, 1];
const WIDTHS = [0.05, 0.24, 0.53, 0.74, 0.94, 1, 0.96, 0.82, 0.58, 0.34, 0.12];
const SHAPE_AREA = STATIONS.slice(1).reduce(
  (sum, y, i) => sum + ((y - STATIONS[i]) * (WIDTHS[i] + WIDTHS[i + 1])) / 2,
  0,
);
export function parameters(input) {
  const areaAcres = Number(input.areaAcres),
    ratio = Number(input.ratio),
    resolution = Number(input.resolution ?? 1);
  if (
    !Number.isFinite(areaAcres) ||
    areaAcres < 0.1 ||
    areaAcres > 100000 ||
    !Number.isFinite(ratio) ||
    ratio < 0.25 ||
    ratio > 4 ||
    resolution !== 1
  )
    throw new Error(
      "Area or shape ratio is outside the supported range, or the fixed baseline was changed.",
    );
  return { areaAcres, ratio, resolution };
}
export function geometry(input, shape = "book") {
  const p = parameters(input),
    area = p.areaAcres * ACRE_M2;
  const length = Math.sqrt(
    area / (p.ratio * (shape === "drop" ? SHAPE_AREA : 1)),
  );
  return {
    area,
    length,
    width: p.ratio * length,
    swmmWidth: 2 * Math.sqrt(area / p.ratio),
  };
}
export function halfWidth(yFraction, maxWidth, shape) {
  if (shape === "book") return maxWidth / 2;
  const i = Math.min(
    STATIONS.length - 2,
    Math.max(0, STATIONS.findIndex((y) => y > yFraction) - 1),
  );
  if (yFraction >= 1) return (WIDTHS.at(-1) * maxWidth) / 2;
  const f = (yFraction - STATIONS[i]) / (STATIONS[i + 1] - STATIONS[i]);
  return ((WIDTHS[i] * (1 - f) + WIDTHS[i + 1] * f) * maxWidth) / 2;
}
export function bed(x, y, sideSlope = CONFIG.sideSlope) {
  return sideSlope * (Math.abs(x) + y / 4);
}
export function stormRates(storm) {
  const cumulative = storm.temporal.cumulative_fraction;
  if (!cumulative || cumulative.length !== 49)
    throw new Error("The NOAA storm record is incomplete.");
  return cumulative
    .slice(1)
    .map(
      (v, i) => (v - cumulative[i]) * storm.frequency.depth_inches * 25.4 * 2,
    );
}
export function buildModel(input, method, storm, mesh = null) {
  const p = parameters(input),
    shape = method === "drop" ? "drop" : "book",
    g = geometry(p, shape);
  if (!METHODS.some((m) => m.id === method))
    throw new Error("Unknown comparison method.");
  const slope = input.slopePercent === undefined ? CONFIG.sideSlope : input.slopePercent / 100;
  const shortEvent = Array.isArray(storm.blocksPercent);
  const sections = new Map();
  const add = (key, ...rows) =>
    sections.set(key, [...(sections.get(key) ?? []), ...rows]);
  add(
    "TITLE",
    `NYC ${storm.frequency.return_period_years}-year ${shortEvent ? 1 : 24}-hour | ${method} | ${p.areaAcres} acres | width/length ${p.ratio}`,
  );
  add(
    "OPTIONS",
    "FLOW_UNITS CMS",
    "INFILTRATION HORTON",
    "FLOW_ROUTING DYNWAVE",
    "START_DATE 01/01/2024",
    shortEvent ? "END_DATE 01/01/2024" : "END_DATE 01/03/2024",
    shortEvent ? "END_TIME 08:00:00" : "END_TIME 00:00:00",
    "REPORT_STEP 00:01:00",
    "WET_STEP 00:00:10",
    "DRY_STEP 00:01:00",
    "ROUTING_STEP 10",
    "THREADS 1",
  );
  add("EVAPORATION", "CONSTANT 0");
  add("RAINGAGES", shortEvent ? "RG INTENSITY 0:05 1 TIMESERIES RAIN" : "RG INTENSITY 0:30 1 TIMESERIES RAIN");
  const rain = shortEvent ? storm.blocksPercent.map(percent => percent / 100 * storm.frequency.depth_inches * 25.4 * 12) : stormRates(storm);
  rain.forEach((rate, i) =>
    add(
      "TIMESERIES",
      shortEvent ? `RAIN 01/01/2024 0:${String(i*5).padStart(2,"0")} ${rate.toFixed(9)}` : `RAIN 01/01/2024 ${Math.floor(i / 2)}:${i % 2 ? "30" : "00"} ${rate.toFixed(9)}`,
    ),
  );
  add("TIMESERIES", shortEvent ? "RAIN 01/01/2024 1:00 0" : "RAIN 01/02/2024 0:00 0");
  add(
    "REPORT",
    "CONTINUITY YES",
    "SUBCATCHMENTS ALL",
    "NODES ALL",
    "LINKS ALL",
  );
  if (method === "lumped") {
    add("OUTFALLS", "OUT 0 FREE NO");
      add(
        "SUBCATCHMENTS",
        `S0 RG OUT ${g.area / 10000} 100 ${g.swmmWidth} ${slope * 100} 0`,
      );
      add(
        "SUBAREAS",
        `S0 ${CONFIG.roughness} ${CONFIG.roughness} 0 0 100 OUTLET`,
      );
      add("INFILTRATION", "S0 0 0 0 0 0");
  } else {
    add(
      "2D_OPTIONS",
      "MOMENTUM_EQUATION FULL_SWE",
      "RECONSTRUCTION_ORDER 2",
      "LTS_TIERS 1",
      "CFL_NUMBER 0.4",
      "MAX_TIMESTEP 10",
      "CELL_CLOSURE VFR",
      "FACE_RECONSTRUCTION VFR_FACE",
      "DRY_DEPTH 0.00001",
      "H_MOVE 0.00002",
      "RAINFALL_MODE SYSTEM",
      "EVAPORATION NO",
      "INFILTRATION NO",
      "REPORT_2D NO",
    );
    if (!mesh) throw new Error("A native MeshKit mesh is required for the 1 m² baseline.");
    mesh.vertices.forEach((v) => add("2D_VERTICES", v.map((n) => n.toPrecision(17)).join(" ")));
    mesh.triangles.forEach((v) => add("2D_TRIANGLES", v.join(" ") + " " + CONFIG.roughness + " 0"));
    const openingHalfWidth = halfWidth(0, g.width, shape) / 4;
    mesh.triangles.forEach((cell, index) => {
      for (let edge = 0; edge < 3; edge++) {
        const a = mesh.vertices[cell[(edge + 1) % 3]], b = mesh.vertices[cell[(edge + 2) % 3]];
        if (Math.abs(a[1]) < 1e-8 && Math.abs(b[1]) < 1e-8 && Math.max(Math.abs(a[0]), Math.abs(b[0])) < openingHalfWidth + 1e-8)
          add("2D_BOUNDARY_CONDITIONS", index + " " + edge + " NORMAL_FLOW " + slope / 4);
      }
    });
  }
  return (
    [...sections]
      .map(([key, rows]) => `[${key}]\n${rows.join("\n")}`)
      .join("\n\n") + "\n"
  );
}
