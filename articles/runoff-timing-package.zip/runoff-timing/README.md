# Lumped Runoff vs. Distributed Runoff

Open `index.html` for the article, or open `report.html` for a self-contained explorer. The four sliders select native results for 2-, 25- and 100-year storms, areas of 0.1, 4 and 64 acres, width/length ratios of 0.25, 1 and 4, and side slopes of 0.5% and 2%. The valley grade is one quarter of the side slope. Each of the 54 combinations includes a lumped SWMM reservoir, a 2D open book and a 2D teardrop. The website needs no server-side solver, fetch requests, packages or installation.

## Evidence and interpretation

- `study/summary.csv` contains peak discharge, time to peak, signed differences from lumped SWMM and eight-hour outlet volume for all 162 baseline runs.
- `study/validation.json` contains engine and runner hashes, volume closure, and eight mesh-refinement runs across four selected cases. Two levels measure sensitivity. They cannot establish a converged reference solution.
- `study/runs/` contains native outlet ledgers and reports. Each result includes SHA-256 identities for the native library, runner, input and report. The complete downloadable ZIP also contains the actual input text for all 170 runs.
- `study/design.mjs` defines the twelve five-minute rainfall blocks, triangular meshes and scenario identifiers. Hourly depths are from the NYC partial-duration series in `evidence/atlas14-nyc-pds.txt`. The temporal pattern is synthetic. Peak discharge uses the largest one-minute mean derived from cumulative outlet volume.
- The secondary check uses independently recorded 2D rainfall, boundary outflow and final surface storage. Runoff still on the surface at hour eight explains finite-window differences. This check tests conservation. Peak accuracy requires a separate comparison.
- `baseline-24h.zip` beside the website article preserves the previous edition’s 1 m² mesh study, original code, reports, offline article and figures. The older `matrix/`, `matrix-index.json` and `storm.json` refer to that 24-hour experiment.

## Regenerate

From the website article directory, supply the path to a native OpenSWMM engine library built with 2D support. Node 18+ and a C++17 compiler are needed for generation. On Linux, add `-ldl` to the compiler command. The article's engine identifies itself in each report. PNG export uses librsvg's `rsvg-convert`. Archiving uses `zip` and `unzip`.

```sh
c++ -O2 -std=c++17 native-runner.cpp -o /tmp/runoff-study-runner
node study/run.mjs "$RUNOFF_ENGINE" /tmp/runoff-study-runner 4
for scenario in a0.1-r0.25-s2-y25 a4-r4-s2-y25 a64-r0.25-s2-y25 a64-r0.25-s0.5-y25; do
  node study/run.mjs "$RUNOFF_ENGINE" /tmp/runoff-study-runner 2 "$scenario" 2
done
node study/package.mjs
node build-linkedin-figures.mjs
node assemble.mjs
node pack-report.mjs
node verify.mjs
```

The builder checks all four factors, the NOAA depth row, integrated flows, sampled peaks, per-model rain volume, input slopes, mesh areas, outlet widths, report identities and the 2D water balances before emitting the browser data. The ZIP includes the generator and the compact browser data. Page assembly and full website packaging run in the hydrocouple.github.io checkout with its shared site files present.

Edit `article-content.html` and `linkedin-article.md` to revise the text. Assembly updates the standalone article, the site's article reader and the LinkedIn HTML draft. The LinkedIn figure archive contains the PNG, SVG and Markdown copy. To preview via HTTP, run `node serve.mjs` from this directory and visit `http://127.0.0.1:8769/articles/runoff-timing/`.
