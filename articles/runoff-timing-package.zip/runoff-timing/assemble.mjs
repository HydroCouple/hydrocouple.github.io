// Build both static article pages and the LinkedIn HTML edition. No Python.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)),root=path.resolve(here,'../..');
const content=fs.readFileSync(path.join(here,'article-content.html'),'utf8');
const title='Lumped Runoff vs. Distributed Runoff — When Does the Lumped Approximation Hold?';
const strip=s=>s.replace(/^import [^;]+;\n/gm,'').replace(/^export /gm,'');
const browserScript='// Generated from model.mjs, study/design.mjs and explorer.mjs by assemble.mjs.\n(() => {\n'+
  ['model.mjs','study/design.mjs','study/hyetograph.mjs','terrain.mjs','explorer.mjs'].map(file=>strip(fs.readFileSync(path.join(here,file),'utf8'))).join('\n')+'\n})();\n';
new vm.Script(browserScript);
fs.writeFileSync(path.join(here,'explorer.js'),browserScript);
const article=/<article class="rt-article" id="runoff-timing">[\s\S]*?<\/article>/;
function scripts(page,base) {
  return page.replace(/<script defer src="[^"]*plotly-basic\.min\.js"><\/script>\s*/g,'').replace(/<script defer src="[^"]*study\/data\.js"><\/script>\s*/g,'')
    .replace(/<script defer src="[^"]*explorer\.js"><\/script>/,
      '<script defer src="'+base+'vendor/plotly-basic-3.4.0/plotly-basic.min.js"></script>\n<script defer src="'+base+'study/data.js"></script>\n<script defer src="'+base+'explorer.js"></script>');
}
let standalone=fs.readFileSync(path.join(here,'index.html'),'utf8');
standalone=standalone.replace(article,()=>content.trim().replaceAll('/articles/runoff-timing/','./')
  .replaceAll('/articles/runoff-timing-package.zip','../runoff-timing-package.zip'))
  .replace(/<title>[^<]*<\/title>/,'<title>'+title+' | HydroCouple</title>')
  .replace(/<meta name="description" content="[^"]*">/,'<meta name="description" content="Compare lumped SWMM runoff and spatially explicit overland flow across storm return periods, drainage areas, aspect ratios and slopes.">');
fs.writeFileSync(path.join(here,'index.html'),scripts(standalone,''));
let page=fs.readFileSync(path.join(root,'articles.html'),'utf8');
page=page.replace(article,()=>content.trim().replaceAll('"/articles/','"articles/')).replace(/(data-target="runoff-timing"><span class="art-date">)[^<]*(<\/span><span class="art-title">)[^<]*/,(_,before,between)=>before+'11-23-2026'+between+title);
fs.writeFileSync(path.join(root,'articles.html'),scripts(page,'articles/runoff-timing/'));
const escape=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const sourceBlocks=fs.readFileSync(path.join(here,'linkedin-article.md'),'utf8').trim().split('\n\n'),rendered=[];
for(let i=0;i<sourceBlocks.length;i++){
 const block=sourceBlocks[i],picture=block.match(/^!\[([^\]]*)\]\((figures\/[\w-]+\.png)\)$/);
 if(picture){
  const png=fs.readFileSync(path.join(here,picture[2]));
  const caption=sourceBlocks[i+1]?.match(/^\*(Figure \d+\.[\s\S]*)\*$/);if(caption)i++;
  // Embed the image so the HTML copy retains its figures when shared on its own.
  rendered.push(`<figure class="li-figure"><img src="data:image/png;base64,${png.toString('base64')}" alt="${escape(picture[1])}" width="${png.readUInt32BE(16)}" height="${png.readUInt32BE(20)}">${caption?`<figcaption>${escape(caption[1])}</figcaption>`:''}</figure>`);continue;
 }
 let text=escape(block).replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>').replace(/\[(.*?)\]\((.*?)\)/g,'<a href="$2">$1</a>');
 if(text.startsWith('# '))rendered.push('<h1>'+text.slice(2)+'</h1>');else if(text.startsWith('## '))rendered.push('<h2>'+text.slice(3)+'</h2>');else rendered.push('<p>'+text+'</p>');
}
// Share the acknowledgment from the website's HTML with the LinkedIn HTML edition.
const acknowledgment=content.match(/<h3 id="runoff-acknowledgment">([^<]+)<\/h3>\s*(<p>[\s\S]*?<\/p>)/);
if(acknowledgment) rendered.push('<h2>'+acknowledgment[1]+'</h2>'+acknowledgment[2]);
const figureStyle='figure.li-figure{margin:32px 0 38px}figure.li-figure img{display:block;width:100%;height:auto;border:1px solid #dce5df;border-radius:6px}figure.li-figure figcaption{font-size:14px;line-height:1.6;color:#536b68;margin-top:12px}@media(min-width:1080px){figure.li-figure{margin-left:-85px;margin-right:-85px}}';
let linked=fs.readFileSync(path.join(here,'linkedin-article.html'),'utf8');
linked=linked.replace(/<title>[^<]*<\/title>/,'<title>'+title+' | LinkedIn edition</title>');
linked=linked.replace(/<style id="linkedin-figures-style">[\s\S]*?<\/style>/,'');
linked=linked.replace('</head>',`<style id="linkedin-figures-style">${figureStyle}</style></head>`);
linked=linked.slice(0,linked.indexOf('<nav>'))+'<nav>LinkedIn draft · <a href="./">Interactive article</a> · <a href="linkedin-article.md">Markdown copy</a> · <a href="linkedin-figures.zip" download>Download figure images</a></nav>'+rendered.join('')+linked.slice(linked.indexOf('</body>'));
fs.writeFileSync(path.join(here,'linkedin-article.html'),linked);
