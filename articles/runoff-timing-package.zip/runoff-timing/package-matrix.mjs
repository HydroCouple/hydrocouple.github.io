// Verify native outputs and build a static index. Node.js built-ins only.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
export const here=path.dirname(fileURLToPath(import.meta.url));
export const digest=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
export function parseInput(input){const sections={};let key;for(const line of input.split('\n')){if(line.startsWith('[')){key=line.slice(1,-1);sections[key]=[];}else if(key&&line.trim()&&!line.startsWith(';'))sections[key].push(line.trim().split(/\s+/));}return sections;}
export function meshInfo(input){
 const s=parseInput(input);if(!s['2D_TRIANGLES'])return null;
 const p=s['2D_VERTICES'].map(r=>r.map(Number)),cells=s['2D_TRIANGLES'].map(r=>r.slice(0,3).map(Number));
 const areas=[],edges=[];let opening=0;
 for(const c of cells){const [a,b,d]=c.map(i=>p[i]);const area=((b[0]-a[0])*(d[1]-a[1])-(b[1]-a[1])*(d[0]-a[0]))/2;assert(area>0);areas.push(area);for(let i=0;i<3;i++){const v=p[c[i]],w=p[c[(i+1)%3]];edges.push(Math.hypot(v[0]-w[0],v[1]-w[1]));}}
 for(const row of s['2D_BOUNDARY_CONDITIONS']){const c=cells[Number(row[0])],e=Number(row[1]),a=p[c[(e+1)%3]],b=p[c[(e+2)%3]];opening+=Math.hypot(a[0]-b[0],a[1]-b[1]);}
 areas.sort((a,b)=>a-b);edges.sort((a,b)=>a-b);
 return {cells:cells.length,cellType:'triangles',target_max_area_m2:1,cell_area_m2:[areas[0],areas.at(-1)],median_area_m2:areas[Math.floor(areas.length/2)],mean_area_m2:areas.reduce((a,b)=>a+b,0)/areas.length,area_m2:areas.reduce((a,b)=>a+b,0),edge_length_m:[edges[0],edges.at(-1)],opening_m:opening,source:'Executed input vertices, triangular cells and boundary edges'};
}
export function packageMatrix(plan=JSON.parse(fs.readFileSync(path.join(here,'matrix-plan.json')))){
 const scenarios=[],engines=new Set();let worst=0;
 for(const scenario of plan.scenarios){const entry={...scenario,files:{},metrics:[],meshes:{}};
  for(const method of plan.methods){
   const stem=`matrix/${scenario.id}/${method.id}`,input=path.join(here,stem+'.inp'),report=path.join(here,stem+'.rpt'),data=path.join(here,stem+'.json');
   const r=JSON.parse(fs.readFileSync(data)),inp=fs.readFileSync(input,'utf8'),rpt=fs.readFileSync(report,'utf8');
   assert.equal(r.identity.input_sha256,digest(input));engines.add(r.identity.engine_sha256);
   assert.equal(r.samples.length,2881);assert(r.peak>0);assert.equal(r.sampling,'native_outlet_ledger_v3');
   r.samples.forEach((row,i)=>{assert.equal(row[0],i*60);assert(row.every(Number.isFinite));assert(row[1]>=0);});
   assert(Math.abs(r.samples.reduce((v,row)=>v+row[1]*60,0)-r.delivered)<r.totalRain*1e-7);
   assert(Math.abs(r.samples.slice(0,1441).reduce((v,row)=>v+row[1]*60,0)-r.samples[1440][2])<r.totalRain*1e-7);
   assert(r.continuity_errors_percent.length>0);const error=Math.max(...r.continuity_errors_percent.map(Math.abs));worst=Math.max(worst,error);assert(error<1);
   assert(!/ERROR\s+\d+/.test(rpt));
   if(method.id==='lumped'){const flood=rpt.match(/Flooding Loss[^\n]*?([-\d.]+)\s+[-\d.]+\s*(?:\n|$)/);assert(flood&&Number(flood[1])===0);}
   const mesh=meshInfo(inp);if(mesh){assert(mesh.cell_area_m2[1]<=1+1e-7);assert(Math.abs(mesh.area_m2-scenario.settings.areaAcres*4046.8564224)<scenario.settings.areaAcres*1e-5);assert(Math.abs(r.balance.rainfallIn-r.totalRain)<r.totalRain*1e-7);assert(Math.abs(r.balance.continuityError)<.01);}
   entry.meshes[method.id]=mesh;
   entry.files[method.id]={data:stem+'.json',input:stem+'.inp',report:stem+'.rpt',data_sha256:digest(data),input_sha256:digest(input),report_sha256:digest(report)};
   entry.metrics.push(Object.fromEntries(['id','peak','peakTime','crestStart','crestEnd','centroid','totalRain','delivered','continuity_errors_percent'].map(k=>[k,r[k]])));
  }scenarios.push(entry);
 }
 assert.equal(engines.size,1);
 const index={schema_version:4,areas:plan.areas,ratios:plan.ratios,storm:plan.storm,scenarios,engine:'Native OpenSWMM 6.0.0-alpha.4',engine_sha256:[...engines][0],native_instances:scenarios.length*plan.methods.length,worst_reported_continuity_percent:worst,mesh_policy:plan.meshPolicy,sampling:'One-minute mean flows from native cumulative outlet volume ledgers',between_points:'None. Sliders select exact completed scenarios.'};
 fs.writeFileSync(path.join(here,'matrix-index.tmp'),JSON.stringify(index));fs.renameSync(path.join(here,'matrix-index.tmp'),path.join(here,'matrix-index.json'));
 fs.writeFileSync(path.join(here,'evidence/validation.json'),JSON.stringify({description:'Actual native engine processes; common 1 m² maximum triangular-cell area; no convergence runs.',geometry_scenarios:scenarios.length,refinement_scenarios:0,native_instances:index.native_instances,worst_reported_continuity_percent:worst,engine_sha256:index.engine_sha256,numerical_qualification:'Baseline selected by the user. Input, area, cell-size, completion and water-volume checks passed; mesh convergence was not assessed.'},null,2));
 fs.writeFileSync(path.join(here,'evidence/runtime.json'),JSON.stringify({engine:index.engine,engine_sha256:index.engine_sha256,execution:'Separate native C++ process and OpenSWMM engine instance per model',sources:Object.fromEntries(['model.mjs','native-mesh.cpp','native-runner.cpp','generate-matrix.mjs','run-matrix.mjs','package-matrix.mjs'].map(n=>[n,digest(path.join(here,n))])),volume_units:'1D cumulative ledger: internal ft³ converted by 0.028316846592. 2D cumulative boundary ledger: m³.',website:'Static HTML, CSS, JavaScript and JSON; no Python, server, solver or npm dependency at runtime.'},null,2));
 console.log(`Packaged ${scenarios.length} scenarios / ${index.native_instances} native records; worst continuity ${worst}%.`);
 return index;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))packageMatrix();
