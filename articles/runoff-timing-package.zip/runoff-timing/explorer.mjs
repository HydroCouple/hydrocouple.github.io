import {rainTicks, rainBars, rainInk} from './study/hyetograph.mjs';
import {terrainViews} from './terrain.mjs';
import {geometry, halfWidth} from './model.mjs';
import {areas, ratios, slopes, periods, depths, methods, hours, inputFor} from './study/design.mjs';

const root = document.getElementById('runoff-explorer');
if (root) initialize(root);

function initialize(root) {
  const $ = id => root.querySelector('#rt-'+id);
  const fmt=(n,d=2)=>n.toLocaleString('en-US',{maximumFractionDigits:d});
  const signed=(n,d=1)=>n===0?'0':(n>0?'+':'−')+Math.abs(n).toFixed(d);
  const cfs=35.3146667;
  const controls=[
    {id:'storm',field:'period',values:periods,format:v=>v+' years · '+depths[v].toFixed(2)+' in'},
    {id:'area',field:'areaAcres',values:areas,format:v=>v+' acres'},
    {id:'ratio',field:'ratio',values:ratios,format:v=>String(v)},
    {id:'slope',field:'slopePercent',values:slopes,format:v=>v+'%'}
  ];
  const rows=globalThis.RUNOFF_STUDY;
  if(!Array.isArray(rows)||rows.length!==areas.length*ratios.length*periods.length*slopes.length) {
    $('status').textContent='The simulation data could not be loaded. Open the offline report to explore the complete matrix.';
    return;
  }
  let current, view='flow', zoom=true;
  function select() {
    const selected={};
    for(const c of controls) {
      const el=$(c.id), value=c.values[+el.value];
      selected[c.field]=value;
      $(c.id+'-value').textContent=c.format(value);
      el.setAttribute('aria-valuetext',c.format(value));
    }
    current=rows.find(s=>controls.every(c=>s[c.field]===selected[c.field]));
    if(!current) throw Error('Missing completed scenario');
    const s=current, base=s.runs[0];
    $('status').textContent=`${s.period}-year storm · ${s.areaAcres} acres · width/length ${s.ratio} · side slope ${s.slopePercent}% · valley slope ${s.slopePercent/4}%`;
    $('metrics').innerHTML=s.runs.map((r,i)=>{
      const difference=100*(r.peak/base.peak-1), delay=(r.peakTime-base.peakTime)/60;
      return `<tr><th scope="row">${methods[i].label}</th><td>${fmt(r.peak*cfs,3)}</td><td><strong>${i?signed(difference)+'%':'Reference'}</strong></td><td>${r.peakTime/60}</td><td><strong>${i?signed(delay,0):'—'}</strong></td><td>${fmt(r.centroid/60,1)}</td></tr>`;
    }).join('');
    $('volumes').innerHTML=s.runs.map((r,i)=>
      `<tr><th scope="row">${methods[i].label}</th><td>${fmt(r.rain,3)}</td><td>${fmt(r.atRainEnd,3)}</td><td>${fmt(r.volume,3)}</td><td>${i?signed(100*(r.volume/base.volume-1),3)+'%':'Reference'}</td><td>${i?fmt(r.storage,4):'—'}</td><td>${i?(Math.abs(r.closure)<0.000001?'&lt;0.000001%':fmt(Math.abs(r.closure),6)+'%'):'—'}</td></tr>`
    ).join('');
    const terrain = terrainViews(s);
    for(const id of ['book','drop']) {
      const g=geometry(s,id);
      $(id).innerHTML = terrain[id];
      $(id+'-dim').textContent=`${fmt(g.width,1)} m maximum width × ${fmt(g.length,1)} m long · ${fmt(halfWidth(0,g.width,id)/2,2)} m outlet`;
    }
    $('refinement').textContent = s.refinement
      ? 'After doubling mesh resolution in each direction, the change from the plotted 2D result was '+
        s.refinement.map((r,i)=>methods[i+1].label+': '+signed(r.peakChangePct)+'% in peak and '+signed(r.timeChangeMin,0)+' min in timing').join(' · ')+'.'
      : 'This selection uses the baseline mesh. Four selected scenarios also have a finer-mesh check.';
    chart();
  }
  function chart() {
    const s=current;
    const peaks=s.runs.map(r=>r.peakTime/60);
    const lo=zoom?Math.max(0,Math.min(...peaks)-20):0;
    const hi=zoom?Math.min(hours*60,Math.max(...peaks)+30):hours*60;
    const value=(q,v)=>view==='volume'?100*v/s.runs[0].rain:q*cfs/(view==='unit'?s.areaAcres:1);
    const curves=s.runs.map(r=>r.samples.slice(lo,hi+1).map(([q,v],i)=>[i+lo,value(q,v)]));
    const top=Math.max(...curves.flat().map(p=>p[1]))*1.07;
    const left=81, right=925;
    const rainTop=32, rainBottom=140, plotTop=190, bottom=465;
    const x=t=>left+(t-lo)/(hi-lo)*(right-left);
    const y=v=>bottom-v/top*(bottom-plotTop);
    const rainY=intensity=>rainTop+intensity/rainTicks.at(-1)*(rainBottom-rainTop);
    const path=points=>points.map(([t,v],i)=>(i?'L':'M')+x(t).toFixed(2)+','+y(v).toFixed(2)).join(' ');
    const label=(a,b,str,align='middle')=>`<text x="${a}" y="${b}" text-anchor="${align}" font-size="15" fill="#3e5855">${str}</text>`;
    let mark=`<defs><clipPath id="rt-plot-clip"><rect x="${left}" y="${plotTop-2}" width="${right-left}" height="${bottom-plotTop+4}"/></clipPath></defs>`;
    mark+=`<path d="M${left},${rainTop} H${right}" stroke="${rainInk}"/>`;
    mark+=rainBars(s.period,x,rainY,lo,hi);
    for(let i=0;i<=4;i++) {
      const v=top*i/4;
      mark+=`<path d="M81,${y(v)} H${right}" stroke="#dbe4e1"/>`+label(72,y(v)+5,fmt(v,top<2?2:1),'end');
    }
    for(let i=0;i<=5;i++) {const t=lo+(hi-lo)*i/5;mark+=label(x(t),bottom+27,fmt(t,1));}
    mark+=`<path d="M${right},${rainTop} V${rainBottom}" stroke="${rainInk}"/>`;
    for(const tick of rainTicks) {
      const tickY=rainY(tick);
      mark+=`<path d="M${right},${tickY} h6" stroke="${rainInk}"/><text x="${right+12}" y="${tickY+5}" font-size="15" fill="${rainInk}">${tick}</text>`;
    }
    mark+=`<text x="${right}" y="20" text-anchor="end" font-size="16" fill="${rainInk}">Rainfall (in/h)</text>`;
    const colors=methods.map(m=>m.color), dashes=['9 5','','4 4'];
    curves.forEach((pts,i)=>{mark+=`<path d="${path(pts)}" clip-path="url(#rt-plot-clip)" fill="none" stroke="${colors[i]}" stroke-width="3" stroke-dasharray="${dashes[i]}"/>`;});
    if(view!=='volume') s.runs.forEach((r,i)=>{mark+=`<circle cx="${x(r.peakTime/60)}" cy="${y(value(r.peak,0))}" r="4" fill="${colors[i]}"/>`;});
    const flowLabel=view==='volume'?'Cumulative volume (% of rain)':view==='unit'?'Outlet flow (ft³/s per acre)':'Outlet flow (ft³/s)';
    $('chart-label').textContent=flowLabel;
    $('chart').innerHTML=mark+label(left,plotTop-13,flowLabel,'start')+label((left+right)/2,bottom+59,'Minutes from storm start');
  }
  for (const c of controls) {
    const input=$(c.id); input.max=String(c.values.length-1);
    input.addEventListener('input',select); input.disabled=false;
  }
  root.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>{
    view=b.dataset.view;
    root.querySelectorAll('[data-view]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));
    chart();
  });
  $('zoom').onclick=()=>{zoom=!zoom;$('zoom').setAttribute('aria-pressed',String(zoom));chart();};
  const download=(filename,text,type='text/plain')=>{
    const url=URL.createObjectURL(new Blob([text],{type})), a=document.createElement('a');
    a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  };
  $('csv').onclick=()=>{
    const rows=['minute,'+methods.flatMap(m=>[m.id+'_cfs',m.id+'_volume_m3']).join(',')];
    current.runs[0].samples.forEach((_,i)=>rows.push([i,...current.runs.flatMap(r=>[r.samples[i][0]*cfs,r.samples[i][1]])].join(',')));
    download(current.id+'.csv',rows.join('\n')+'\n','text/csv');
  };
  for(const ext of ['inp','rpt']) $(ext).onclick=()=>{
    const method=$('model').value, idx=methods.findIndex(m=>m.id===method);
    download(current.id+'-'+method+'.'+ext,ext==='inp'?inputFor(current,method):current.runs[idx].report);
  };
  select();
}
