// Portable standalone explorer and an archive with all executed inputs, reports and ledgers.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {scenarios, methods, inputFor} from './study/design.mjs';
const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'../..');
const read=f=>fs.readFileSync(path.join(here,f),'utf8');
const dataUrl=(file,mime)=>'data:'+mime+';base64,'+fs.readFileSync(file).toString('base64');
const live='https://www.hydrocouple.org/';
let page=read('index.html');
for(const src of ['study/data.js','explorer.js']) {
  const script=read(src);assert(!script.toLowerCase().includes('</script'));
  page=page.replace('<script defer src="'+src+'"></script>',()=>'<script>'+script+'</script>');
}
const css=read('explorer.css');
page=page.replace('<link rel="stylesheet" href="../../css/fonts.css">','')
  .replace('<link rel="stylesheet" href="explorer.css">',()=>'<style>'+css+'</style>')
  .replaceAll('../../img/hydrocouple.png',dataUrl(path.join(root,'img/hydrocouple.png'),'image/png'))
  .replaceAll('src="./figures/storm-matrix-hydrographs.png"','src="'+dataUrl(path.join(here,'figures/storm-matrix-hydrographs.png'),'image/png')+'"')
  .replaceAll('href="./study/summary.csv" download','href="'+dataUrl(path.join(here,'study/summary.csv'),'text/csv')+'" download="runoff-matrix.csv"')
  .replaceAll('href="../../index.html"','href="'+live+'"').replaceAll('href="../../articles.html','href="'+live+'articles.html')
  .replaceAll('href="../runoff-timing-package.zip"','href="'+live+'articles/runoff-timing-package.zip"')
  .replaceAll('href="./report.html" download','href="report.html" download')
  .replaceAll('href="./','href="'+live+'articles/runoff-timing/');
fs.writeFileSync(path.join(here,'report.html'),page);
const temp=fs.mkdtempSync(path.join(os.tmpdir(),'runoff-package-'));
const dir=path.join(temp,'runoff-timing'), archive=path.join(here,'../runoff-timing-package.zip');
try {
  for(const file of ['index.html','report.html','explorer.css','explorer.js','explorer.mjs','README.md','article-content.html',
    'study','model.mjs','terrain.mjs','native-runner.cpp','package-matrix.mjs','assemble.mjs','pack-report.mjs','verify.mjs',
    'build-linkedin-figures.mjs','linkedin-article.html','linkedin-article.md','linkedin-figures.zip',
    'figures/drainage-shapes.png','figures/drainage-shapes.svg','figures/storm-matrix-hydrographs.png','figures/storm-matrix-hydrographs.svg','evidence/atlas14-nyc-pds.txt']) {
    const dest=path.join(dir,file);fs.mkdirSync(path.dirname(dest),{recursive:true});
    fs.cpSync(path.join(here,file),dest,{recursive:true});
  }
  for(const name of fs.readdirSync(path.join(dir,'study/runs'))) {
    const fine=name.endsWith('-fine'), s=scenarios.find(row=>row.id===name.replace(/-fine$/,''));
    for(const method of methods.filter(m=>!fine||m.id!=='lumped')) {
      const stem=path.join(dir,'study/runs',name,method.id);
      const input=inputFor(s,method.id,fine?2:1);
      const r=JSON.parse(fs.readFileSync(stem+'.json'));
      assert.equal(createHash('sha256').update(input).digest('hex'),r.identity.input);
      fs.writeFileSync(stem+'.inp',input);
    }
  }
  const tmpZip=archive+'.tmp.zip';fs.rmSync(tmpZip,{force:true});
  execFileSync('zip',['-qr',tmpZip,'runoff-timing'],{cwd:temp});
  execFileSync('unzip',['-tq',tmpZip]);fs.renameSync(tmpZip,archive);
} finally {fs.rmSync(temp,{recursive:true,force:true});}
