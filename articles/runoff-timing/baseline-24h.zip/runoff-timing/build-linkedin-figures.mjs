// Static, data-derived SVG/PNG figures. Node built-ins + librsvg; no Python.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {geometry, halfWidth, bed, STATIONS, METHODS, stormRates} from './model.mjs';

const here=path.dirname(fileURLToPath(import.meta.url));
const out=path.join(here,'figures');fs.mkdirSync(out,{recursive:true});
const index=JSON.parse(fs.readFileSync(path.join(here,'matrix-index.json')));
assert.equal(index.native_instances,30);assert.equal(index.schema_version,4);
const sources=new Map();
const runs=(area,ratio)=>{
 const s=index.scenarios.find(s=>s.settings.areaAcres===area&&s.settings.ratio===ratio);assert(s);
 return METHODS.map(m=>{
  const p=s.files[m.id],bytes=fs.readFileSync(path.join(here,p.data));
  assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'),p.data_sha256);
  sources.set(p.data,p.data_sha256);return JSON.parse(bytes);
 });
};
const C={ink:'#193d3a',muted:'#536b68',paper:'#fafbf8',line:'#dce5df',rain:'#9aa19a',...Object.fromEntries(METHODS.map(m=>[m.id,m.color]))};
const esc=s=>String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const text=(x,y,s,size=26,fill=C.ink,anchor='start',weight=400)=>`<text x="${x}" y="${y}" font-size="${size}" fill="${fill}" text-anchor="${anchor}" font-weight="${weight}">${esc(s)}</text>`;
const line=(x1,y1,x2,y2,color=C.line,width=2,dash='')=>`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${color}" stroke-width="${width}"${dash?` stroke-dasharray="${dash}"`:''}/>`;
const rect=(x,y,w,h,fill,rx=0)=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" fill="${fill}"/>`;
const circle=(x,y,r,fill)=>`<circle cx="${x}" cy="${y}" r="${r}" fill="${fill}"/>`;
const clock=s=>`${String(Math.floor(s/3600)).padStart(2,'0')}:${String(Math.round(s/60)%60).padStart(2,'0')}`;
const delta=n=>(n>0?'+':'')+n.toFixed(1);
const acft=m3=>(m3/1233.48183754752).toFixed(6);
const cfs=q=>q*35.3146667;
const dash={lumped:'12 7',book:'',drop:'3 7'};
function start(n,title,subtitle,height){return `<svg xmlns="http://www.w3.org/2000/svg" width="1600" height="${height}" viewBox="0 0 1600 ${height}"><style>text{font-family:Arial,Helvetica,sans-serif}path,line{stroke-linecap:round;stroke-linejoin:round}</style>${rect(0,0,1600,height,C.paper)}${text(65,58,`HYDROCOUPLE  /  RUNOFF TIMING  /  FIGURE ${n}`,21,C.muted,'start',700)}${text(65,125,title,50,C.ink,'start',700)}${text(65,174,subtitle,26,C.muted)}`;}
const footer=(height,s)=>line(65,height-65,1535,height-65)+text(65,height-28,s,20,C.muted)+text(1535,height-28,'Caleb Buahin · November 2026',20,C.muted,'end');
function legend(x,y,id,label){return line(x,y-8,x+55,y-8,C[id],4,dash[id]||'')+text(x+72,y,label,24,C.ink);}

// Figure 1: actual footprint proportions, consistent projection and drainage directions.
function representations(){
 const H=1100,s={areaAcres:.1,ratio:.25,resolution:1},scenario=index.scenarios.find(r=>r.id==='a0.1-r0.25-m1');
 let svg=start(1,'Same rain. Different runoff representations.','0.1 acre · width / length = 0.25 · synthetic basins with no losses',H);
 const xs=[65,575,1085],titles=['SWMM subcatchment','2D open book','2D teardrop'],subs=['One nonlinear reservoir','Two slopes feed the central valley','A changing width and a narrow toe'];
 xs.forEach((x,i)=>{svg+=rect(x,225,450,665,'#ffffff',14)+text(x+24,278,titles[i],29,C.ink,'start',700)+text(x+24,320,subs[i],23,C.muted);});
 svg+='<defs><marker id="flow-arrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto"><path d="M0 0 L7 3.5 L0 7 Z" fill="#087f78"/></marker></defs>';
 const arrow=(a,b,width=3)=>`<path d="M${a} L${b}" fill="none" stroke="${C.book}" stroke-width="${width}" marker-end="url(#flow-arrow)"/>`;
 svg+=text(285,379,'Rainfall',26,C.muted,'middle');
 for(const x of [155,230,305])svg+=arrow(`${x},395`,`${x},470`);
 svg+=rect(115,500,250,125,'#d3e6e0')+`<path d="M115 470 V635 H365 V470" fill="none" stroke="${C.ink}" stroke-width="3"/>`;
 svg+=text(240,553,'Surface storage',27,C.ink,'middle',700)+text(240,594,'depth h',25,C.muted,'middle')+arrow('365,605','465,605')+text(431,649,'Runoff Q',23,C.ink,'middle');
 svg+=text(290,723,'Q ∝ (W/n) √S h⁵⁄³',31,C.lumped,'middle',700)+text(290,779,'Equivalent width W = 2L',25,C.ink,'middle')+text(290,819,'Sheet-flow distance = B/2',25,C.muted,'middle')+text(290,859,'Polygon alone adds no travel path',22,C.muted,'middle');
 const scale=7.9;
 for(const [i,shape]of ['book','drop'].entries()){
  const x=xs[i+1],g=geometry(s,shape),levels=shape==='drop'?STATIONS:Array.from({length:13},(_,j)=>j/12);
  const proj=(a,b)=>[x+225+scale*(.92*a+.28*(b-g.length/2)),680+scale*(.20*a-.70*b-bed(a,b)*8)];
  const pt=(a,b)=>proj(a,b).map(n=>n.toFixed(2)).join(',');
  for(let j=levels.length-2;j>=0;j--)for(const sign of [-1,1]){
   const y0=levels[j]*g.length,y1=levels[j+1]*g.length,h0=halfWidth(levels[j],g.width,shape),h1=halfWidth(levels[j+1],g.width,shape);
   svg+=`<polygon points="${pt(0,y0)} ${pt(sign*h0,y0)} ${pt(sign*h1,y1)} ${pt(0,y1)}" fill="${sign<0?'#dce9d9':'#bfd7cb'}" stroke="#a5bfb0" stroke-width="1"/>`;
  }
  svg+=`<path d="M${pt(0,g.length)} L${pt(0,0)}" stroke="${C.book}" stroke-width="4"/>`;
  for(const f of [.28,.55,.82])for(const sign of [-1,1])svg+=arrow(pt(sign*halfWidth(f,g.width,shape)*.85,f*g.length),pt(sign*halfWidth(f,g.width,shape)*.08,(f-.045)*g.length),2.8);
  svg+=arrow(pt(0,.4*g.length),pt(0,.09*g.length),3.8);
  const p=proj(0,0);svg+=circle(...p,5,C.ink)+text(p[0],p[1]+32,'Outlet',24,C.ink,'middle');
  svg+=text(x+225,779,`${(g.width/.3048).toFixed(1)} ft wide × ${(g.length/.3048).toFixed(1)} ft long`,24,C.ink,'middle')+text(x+225,819,`${(scenario.meshes[shape].opening_m/.3048).toFixed(2)} ft outlet opening`,25,C.muted,'middle')+text(x+225,859,`${scenario.meshes[shape].cells} triangular cells`,23,C.muted,'middle');
 }
 svg+=text(65,945,'Side slopes 2% · center slope 0.5% · Manning’s n = 0.030 · maximum cell area 1 m²',26,C.ink);
 svg+=text(65,990,'Terrain elevation exaggerated ×8. Diagram lines are schematic; outlet widths differ between the two shapes.',24,C.muted);
 return svg+footer(H,'Geometry and outlet widths from executed model inputs. Teardrop dimensions use its maximum width.')+'</svg>';
}

function curve(points,x,y,w,h,xlim,ylim,color,width,dotted='',clip=''){
 const xy=points.filter(p=>p[0]>=xlim[0]&&p[0]<=xlim[1]).map(p=>`${(x+(p[0]-xlim[0])/(xlim[1]-xlim[0])*w).toFixed(3)},${(y+h-(p[1]-ylim[0])/(ylim[1]-ylim[0])*h).toFixed(3)}`);
 return `<path d="M${xy.join(' L')}" fill="none" stroke="${color}" stroke-width="${width}"${dotted?` stroke-dasharray="${dotted}"`:''}${clip?` clip-path="url(#${clip})"`:''}/>`;
}
function hydrographs(){
 const H=1180,records=runs(.1,.25),base=records[0],rain=stormRates(index.storm),area=.1*4046.8564224;
 let svg=start(2,'Similar peaks can hide different delivery times','0.1-acre elongated basin · width / length = 0.25 · NYC 25-year, 24-hour storm',H);
 svg+=legend(65,225,'lumped','SWMM lumped')+legend(440,225,'book','2D open book')+legend(815,225,'drop','2D teardrop')+line(1190,217,1245,217,C.rain,3,'5 7')+text(1262,225,'Rainfall supply',24);
 const panels=[{x:145,xlim:[0,24],ylim:[0,.08],xt:[0,6,12,18,24],yt:[0,.02,.04,.06,.08],title:'Full rainfall period',note:'Hours since storm start',id:'full'}, {x:920,xlim:[9,12],ylim:[.060,.072],xt:[9,10,11,12],yt:[.060,.064,.068,.072],title:'Peak detail · vertical axis enlarged',note:'Hours since storm start',id:'zoom'}];
 const y=340,w=600,h=355;
 for(const p of panels){
  svg+=text(p.x-30,290,p.title,29,C.ink,'start',700)+text(p.x,325,'Outlet flow (ft³/s)',23,C.muted);
  svg+=`<defs><clipPath id="${p.id}"><rect x="${p.x}" y="${y}" width="${w}" height="${h}"/></clipPath></defs>`;
  for(const v of p.yt){const yy=y+h-(v-p.ylim[0])/(p.ylim[1]-p.ylim[0])*h;svg+=line(p.x,yy,p.x+w,yy)+text(p.x-16,yy+7,v.toFixed(p.id==='zoom'?3:2),23,C.muted,'end');}
  for(const v of p.xt){const xx=p.x+(v-p.xlim[0])/(p.xlim[1]-p.xlim[0])*w;svg+=line(xx,y+h,xx,y+h+9,C.muted)+text(xx,y+h+39,v,24,C.muted,'middle');}
  const rainPoints=rain.flatMap((r,i)=>[[i*.5,cfs(r*.001/3600*area)],[(i+1)*.5,cfs(r*.001/3600*area)]]);
  svg+=curve(rainPoints,p.x,y,w,h,p.xlim,p.ylim,C.rain,3,'5 7',p.id);
  // Styles and differing dash patterns retain the comparison when curves overlap.
  for(const r of records)svg+=curve(r.samples.map(s=>[s[0]/3600,cfs(s[1])]),p.x,y,w,h,p.xlim,p.ylim,C[r.id],3.4,dash[r.id],p.id);
  svg+=text(p.x+w/2,y+h+82,p.note,24,C.muted,'middle');
 }
 svg+=line(65,812,1535,812)+text(80,855,'Representation',25,C.muted)+text(655,855,'Peak (ft³/s)',25,C.muted,'end')+text(955,855,'Peak time',25,C.muted,'end')+text(1515,855,'Mean arrival vs. SWMM',25,C.muted,'end');
 records.forEach((r,i)=>{const yy=914+i*62;svg+=circle(91,yy-9,7,C[r.id])+text(110,yy,METHODS[i].label,26)+text(655,yy,cfs(r.peak).toFixed(6),27,C.ink,'end',700)+text(955,yy,clock(r.peakTime),27,C.ink,'end')+text(1515,yy,i?`${delta((r.centroid-base.centroid)/60)} min`:'Reference',27,C.ink,'end',700);});
 return svg+footer(H,'One-minute native outlet flows; mean arrival uses the full 48-hour run. Rainfall supply = rain rate × area.')+'</svg>';
}

function timing(){
 const H=1040;let svg=start(3,'Mean arrival changes with watershed shape','Positive = later than lumped SWMM · negative = earlier · all 10 completed geometries',H);
 svg+=legend(65,237,'book','2D open book')+legend(480,237,'drop','2D teardrop')+text(1535,237,'Same 1 m² maximum cell area',24,C.muted,'end');
 const y=365,h=400,scale=v=>y+h-(v+6)/13*h;
 for(const [i,area]of [.1,.3].entries()){
  const x=145+i*775,w=600;svg+=text(x-35,310,`${area} acre`,34,C.ink,'start',700)+text(x,346,'Mean arrival difference (min)',23,C.muted);
  for(const v of [-6,-4,-2,0,2,4,6])svg+=line(x,scale(v),x+w,scale(v),v===0?'#617974':C.line,v===0?2.5:1.5)+text(x-15,scale(v)+7,v>0?'+'+v:v,23,C.muted,'end');
  for(const [j,ratio]of index.ratios.entries()){
   const rs=runs(area,ratio),base=rs[0],cx=x+60+j*120;
   for(const [k,r]of rs.slice(1).entries()){
    const v=(r.centroid-base.centroid)/60,xx=cx+(k?22:-22),yy=scale(v),zero=scale(0);
    svg+=rect(xx-16,Math.min(yy,zero),32,Math.abs(yy-zero),C[r.id],2);
    svg+=text(cx+(k?5:-5),v>=0?yy-13:yy+27,delta(v),21,C[r.id],k?'start':'end',700);
   }
   svg+=text(cx,y+h+43,ratio,25,C.muted,'middle');
  }
  svg+=text(x+w/2,y+h+92,'Width / length',26,C.ink,'middle');
 }
 svg+=text(65,929,'0.25 = long and narrow. 4 = wide and short. Each bar is a completed native simulation.',25,C.muted);
 return svg+footer(H,'Flow-weighted arrival time over 48 hours. These small-basin results do not predict city-scale behavior.')+'</svg>';
}

function volumes(){
 const H=1110;let svg=start(4,'Same rainfall volume. Different delivery times.','Elongated basins · width / length = 0.25 · no infiltration, evaporation or depression storage',H);
 svg+=rect(65,235,1470,115,'#eaf0eb',8)+text(85,282,'Representation',26,C.ink,'start',700);
 for(const [x,title,unit]of [[720,'Rainfall','(ac-ft)'],[1000,'Runoff by 24 h','(ac-ft)'],[1275,'Runoff by 48 h','(ac-ft)'],[1510,'Delivered','by 48 h']])svg+=text(x,282,title,25,C.ink,'end',700)+text(x,320,unit,23,C.muted,'end');
 for(const [i,area]of [.1,.3].entries()){
  const top=392+i*300;svg+=text(85,top,`${area} acre`,29,C.ink,'start',700)+line(275,top-9,1510,top-9);
  runs(area,.25).forEach((r,j)=>{const y=top+65+j*68;svg+=circle(94,y-9,7,C[r.id])+text(115,y,METHODS[j].label,25)+text(720,y,acft(r.totalRain),27,C.ink,'end')+text(1000,y,acft(r.samples[1440][2]),27,C.ink,'end')+text(1275,y,acft(r.delivered),27,C.ink,'end',700)+text(1510,y,(100*r.delivered/r.totalRain).toFixed(3)+'%',27,C.ink,'end');});
 }
 svg+=text(65,990,'At a fixed time, the shortfall includes remaining storage and numerical balance error. Values are rounded.',24,C.muted);
 return svg+footer(H,'Cumulative outlet volumes from native engine ledgers. 1 acre-foot = 43,560 ft³.')+'</svg>';
}

const figures=[
 {id:'linkedin-01-representations',height:1100,draw:representations,alt:'SWMM nonlinear storage beside open-book and teardrop terrains, with arrows toward the central valley and outlet.',caption:'Figure 1. Three representations of the same 0.1-acre elongated basin. SWMM uses equivalent width W = 2L; the 2D models resolve the side slopes and central valley. The teardrop has a narrower outlet, which is part of the comparison. Terrain lines are schematic; elevation is exaggerated eightfold.'},
 {id:'linkedin-02-hydrographs',height:1180,draw:hydrographs,alt:'Native hydrographs for a 0.1-acre elongated basin: full rainfall period, enlarged peak detail and timing metrics.',caption:'Figure 2. Native outlet hydrographs for the 0.1-acre elongated case. The right panel enlarges both the time window and vertical scale. The open book peaks earlier while its flow-weighted mean arrival is later. The mean uses all 48 hours, including recession; plotted flows are one-minute means.'},
 {id:'linkedin-03-arrival-time',height:1040,draw:timing,alt:'Mean arrival differences relative to SWMM for five aspect ratios at 0.1 and 0.3 acres, with positive and negative bars.',caption:'Figure 3. Mean arrival time relative to lumped SWMM across all ten geometries. Positive values mean later arrival. Narrow basins and wide basins give different directions of change under this forcing and width convention. Every bar represents a completed simulation.'},
 {id:'linkedin-04-volumes',height:1110,draw:volumes,alt:'Native rainfall and runoff volume table for 0.1- and 0.3-acre elongated basins, showing 24-hour and 48-hour discharge.',caption:'Figure 4. Native cumulative outlet volumes for elongated basins at both simulated areas. Rainfall is identical across methods at each area. Differences at a fixed cutoff include remaining storage and numerical balance error. Volumes are in acre-feet and rounded to six decimals.'},
 {id:'linkedin-05-earlier-example',width:1819,height:983,source:'evidence/earlier-open-book.png',alt:'Earlier 64-acre elongated and square basins under the same 3-inch Type II storm, with much more distinct receiving-node hydrographs.',caption:'Figure 5. The earlier 64-acre diagnostic example, preserved for context. Both shapes in this figure receive the same 3-inch Type II storm. Elongation increases flow distance across the fold. These are local-inertial runs with different meshes, collectors and numerical settings from the current baseline. The earlier report records significant mesh/time-step sensitivity, so its exact peaks are not a converged benchmark. Figures 1–4 do not reproduce this experiment.'},
];
for(const f of figures){
 if(f.source){
  const bytes=fs.readFileSync(path.join(here,f.source));sources.set(f.source,crypto.createHash('sha256').update(bytes).digest('hex'));fs.writeFileSync(path.join(out,f.id+'.png'),bytes);
  const csv='evidence/earlier-open-book.csv';sources.set(csv,crypto.createHash('sha256').update(fs.readFileSync(path.join(here,csv))).digest('hex'));
 }else{
  const svg=f.draw();fs.writeFileSync(path.join(out,f.id+'.svg'),svg);
  execFileSync('rsvg-convert',['--width','2400','--height',String(f.height*1.5),'--output',path.join(out,f.id+'.png'),path.join(out,f.id+'.svg')]);
 }
}
fs.writeFileSync(path.join(out,'manifest.json'),JSON.stringify({description:'Figures 1–4 use the verified current native matrix. Figure 5 preserves the original 64-acre diagnostic image under different forcing and geometry; see experiment-history.json. No model reruns.',current_baseline_engine_sha256:index.engine_sha256,sources:Object.fromEntries(sources),figures:figures.map(({draw,...f})=>({...f,width:f.width||1600,png_width:f.source?f.width:2400,png_height:f.source?f.height:f.height*1.5}))},null,2));
fs.writeFileSync(path.join(out,'README.txt'),'LINKEDIN FIGURES\n\nUpload the numbered PNG files in article order. Figures 1–4 are 2400 pixels wide, with editable SVG originals. Figure 5 is the preserved 1819-pixel-wide historical image; it uses different forcing, geometry and numerical settings. No simulation has been rerun.\n\n'+figures.map(f=>`${f.id}.png\n${f.caption}\nAlt text: ${f.alt}`).join('\n\n')+'\n');
const archive=path.join(here,'linkedin-figures.zip');if(fs.existsSync(archive))fs.unlinkSync(archive);
execFileSync('zip',['-q',archive,...figures.flatMap(f=>(f.source?['png']:['png','svg']).map(ext=>'figures/'+f.id+'.'+ext)),'figures/README.txt','figures/manifest.json','evidence/experiment-history.json'],{cwd:here});
execFileSync('unzip',['-tq',archive]);
console.log('Generated four current-baseline SVG/PNG figure pairs and preserved one historical PNG; packaged linkedin-figures.zip.');
