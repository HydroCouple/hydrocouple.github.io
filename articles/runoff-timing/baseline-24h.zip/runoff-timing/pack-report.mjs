// Bundle the completed native data for offline use and a portable ZIP. No Python.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {execFileSync} from 'node:child_process';
import {here,digest} from './package-matrix.mjs';
const root=path.resolve(here,'../..'),index=JSON.parse(fs.readFileSync(path.join(here,'matrix-index.json'))),files={'matrix-index.json':fs.readFileSync(path.join(here,'matrix-index.json'),'utf8')};
assert.equal(index.schema_version,4,'Package only the completed 1 m² baseline matrix');
for(const scenario of index.scenarios)for(const paths of Object.values(scenario.files))for(const kind of ['input','report','data']){const full=path.join(here,paths[kind]);assert.equal(digest(full),paths[kind+'_sha256']);files[paths[kind]]=fs.readFileSync(full,'utf8');}
assert.equal(Object.keys(files).length,1+3*index.native_instances);
let page=fs.readFileSync(path.join(here,'index.html'),'utf8'),css=fs.readFileSync(path.join(here,'explorer.css'),'utf8');
for(const [family,file]of [['Inter','inter-latin.woff2'],['Sora','sora-latin.woff2']])css+=`\n@font-face{font-family:${family};font-weight:100 900;src:url(data:font/woff2;base64,${fs.readFileSync(path.join(root,'fonts',file)).toString('base64')}) format('woff2')}`;
page=page.replace('<link rel="stylesheet" href="../../css/fonts.css">','').replace('<link rel="stylesheet" href="explorer.css">',()=>'<style>'+css+'</style>');
page=page.replaceAll('../../img/hydrocouple.png','data:image/png;base64,'+fs.readFileSync(path.join(root,'img/hydrocouple.png')).toString('base64')).replaceAll('href="../../index.html"','href="https://www.hydrocouple.org/"').replaceAll('href="../../articles.html#runoff-timing"','href="https://www.hydrocouple.org/articles.html#runoff-timing"').replaceAll('href="/articles/runoff-timing/','href="./').replaceAll('href="/articles/runoff-timing-package.zip"','href="../runoff-timing-package.zip"');
page=page.replace(/src="\/articles\/runoff-timing\/figures\/([\w-]+\.png)"/g,(_,file)=>'src="data:image/png;base64,'+fs.readFileSync(path.join(here,'figures',file)).toString('base64')+'"');
const script='globalThis.RUNOFF_FILES=JSON.parse(document.getElementById("native-run-files").textContent);\n'+fs.readFileSync(path.join(here,'explorer.js'),'utf8');
new vm.Script(script);assert(!script.toLowerCase().includes('</script'));
const embedded='<script id="native-run-files" type="application/json">'+JSON.stringify(files).replaceAll('<','\\u003c')+'</script><script>'+script+'</script>';
assert(page.includes('<script defer src="explorer.js"></script>'));
page=page.replace('<script defer src="explorer.js"></script>',()=>embedded);fs.writeFileSync(path.join(here,'report.html'),page);
const archive=path.join(here,'../runoff-timing-package.zip'),temp=path.join(here,'../runoff-timing-package-new.zip');if(fs.existsSync(temp))fs.unlinkSync(temp);
const selected=new Set(index.scenarios.map(s=>s.id));
const paths=[];function walk(directory){for(const item of fs.readdirSync(directory,{withFileTypes:true})){if(item.name.startsWith('.')||item.name==='__pycache__')continue;if(directory===path.join(here,'matrix')&&!selected.has(item.name))continue;const full=path.join(directory,item.name);if(item.isDirectory())walk(full);else if(!/\.(py|lock|tmp)$/.test(item.name))paths.push(path.relative(path.dirname(here),full));}}walk(here);
assert.equal(paths.filter(p=>p.endsWith('.inp')).length,index.native_instances);
execFileSync('zip',['-q',temp,'-@'],{cwd:path.dirname(here),input:paths.join('\n')+'\n'});execFileSync('unzip',['-tq',temp]);fs.renameSync(temp,archive);
console.log(`Offline report ${(fs.statSync(path.join(here,'report.html')).size/1e6).toFixed(1)} MB; ZIP ${(fs.statSync(archive).size/1e6).toFixed(1)} MB; ${index.native_instances} native records.`);
