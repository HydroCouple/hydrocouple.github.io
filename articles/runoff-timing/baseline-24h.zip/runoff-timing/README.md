# Watershed shape and runoff timing — 1 m² baseline

The website is static HTML, CSS, JavaScript and JSON, compatible with GitHub Pages. It has no Python, server-side code, npm packages, browser hydraulic solver or interpolation between simulated cases. `report.html` is the portable report with all completed data and original model inputs/reports embedded; open it directly without a server.

The comparison has three representations: one lumped SWMM subcatchment, a 2D open book and a 2D teardrop. Every result is from an actual native OpenSWMM engine process. The tables show peak timing, peak delay, flow-weighted mean arrival time and cumulative outlet volumes at 24 and 48 hours.

Both 2D shapes use native MeshKit constrained triangulation with the same 1 m² maximum cell area and 25° minimum-angle target. Smaller cells are permitted at geometry constraints. The exact perimeter, central fold and outlet endpoints are retained. This is one user-selected baseline; there are no convergence or refinement simulation series. The batch covers 0.1 and 0.3 acres at width/length ratios 0.25, 0.5, 1, 2 and 4: ten geometries and thirty native runs. Larger models are excluded for practical local turnaround, without coarsening them.

The storm is the NYC 25-year, 24-hour point depth of 6.77 inches, with NOAA Area 2's second-quartile median temporal pattern. Inputs start dry with no infiltration, evaporation or depression storage. The model runs for 48 hours. Each 2D opening occupies the central quarter of its own downstream edge; the narrower teardrop outlet remains a physical difference, described in the article.

## Offline generation — no Python

Node.js uses built-in modules only. The two small C++ adapters use native MeshKit and the native OpenSWMM shared library. These tools run before publication, never on GitHub Pages. The supplied adapters currently target macOS/Linux. A C++17 compiler and a built native MeshKit library are needed to regenerate meshes; no mesher or compiler is required to view the completed report.

Compile `native-mesh.cpp` against `meshkit_core` and `meshkit_predicates`, with the MeshKit include directory. Compile `native-runner.cpp` with a C++17 compiler; on Linux link `-ldl`. In the sibling OpenSWMM GUI checkout, the native MeshKit library is under `libraries/meshkit`, with no Qt or Python dependency. For example, from the website checkout:

```sh
c++ -std=c++17 -O2 articles/runoff-timing/native-mesh.cpp -I ../openswmm.gui/libraries/meshkit/include ../openswmm.gui/build/libraries/meshkit/libmeshkit_core.a ../openswmm.gui/build/libraries/meshkit/libmeshkit_predicates.a -o /tmp/native-mesh
c++ -std=c++17 -O2 articles/runoff-timing/native-runner.cpp -o /tmp/native-runner
node articles/runoff-timing/generate-matrix.mjs --mesher /tmp/native-mesh --areas 0.1,0.3
node articles/runoff-timing/run-matrix.mjs --engine /absolute/path/libopenswmm.engine.dylib --runner /tmp/native-runner --workers 3
node articles/runoff-timing/package-matrix.mjs
node articles/runoff-timing/assemble.mjs
node articles/runoff-timing/verify.mjs
node articles/runoff-timing/pack-report.mjs
```

Select the available area range explicitly when generating. MeshKit refuses a single mesh above the adapter's 250,000-cell cap; that cap is a resource guard, not a claim that a full 48-hour run at that size is practical. `run-matrix.mjs` accepts `--scenario`, `--method` and a comma-separated `--areas` filter. Completed results are reused only when input and native engine hashes match. One lock per model prevents overlapping writers; inspect its process before removing a stale lock after interruption.

`package-matrix.mjs` checks hashes, basin area, cell-size limits, complete minute axes, volume reconciliation, continuity and flooding before publishing the index. `verify.mjs` also verifies exact generated inputs, outlet widths, central-fold representation and static UI structure. A small volume error does not establish mesh convergence or field validation.

## Editing and delivery

Edit `article-content.html` and `linkedin-article.md`, then run `assemble.mjs`. The latter updates the standalone page, `articles.html` and LinkedIn HTML edition. `pack-report.mjs` embeds the selected completed data and builds `../runoff-timing-package.zip` using the system `zip` command. The ZIP contains the report, model inputs/reports, native-output data and generation sources; it excludes superseded hidden archives and Python scripts.

The LinkedIn edition includes four current-baseline figures: representations and drainage directions, native hydrographs, mean arrival by shape, and cumulative volumes. Its HTML embeds the PNG images for sharing as one file. `linkedin-figures.zip` contains separate 2400-pixel-wide PNGs for uploading to LinkedIn, editable SVG originals, captions, alt text and source hashes. To rebuild the figures from completed outputs, run `node articles/runoff-timing/build-linkedin-figures.mjs` before `assemble.mjs`; PNG export uses the native `rsvg-convert` tool (librsvg), with no Python or browser runtime dependency. No model reruns are needed. A fifth figure preserves the original 64-acre diagnostic image, with its own forcing, geometry and numerical caveats. `evidence/experiment-history.json` records the differences and source hashes; it is not part of the current 30-run matrix.

The prior UK benchmark article is withdrawn from the article index; its historical source and evidence are marked archived. Website changes remain local until committed and pushed by the site owner.
