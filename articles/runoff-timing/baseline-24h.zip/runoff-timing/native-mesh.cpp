// Offline MeshKit adapter. No Python and no browser/runtime dependency.
#include "meshkit/job.hpp"
#include <fstream>
#include <iostream>
#include <iomanip>
#include <cmath>
#include <stdexcept>
int main(int argc, char** argv) { try {
  if (argc != 3) throw std::runtime_error("native-mesh request.txt mesh.json");
  std::ifstream in(argv[1]);
  size_t np, nr; double maxArea;
  in >> np >> nr >> maxArea;
  if (!in || !(maxArea > 0) || np > 100000) throw std::runtime_error("Invalid mesh request");
  meshkit::JobRequest request;
  for (size_t i=0; i<np; ++i) { double x,y; in>>x>>y; request.points.emplace_back(x,y); }
  for (size_t i=0; i<nr; ++i) {
    int kind, closed; size_t n; in>>kind>>closed>>n;
    meshkit::Path path; path.kind=kind==0?meshkit::PathKind::Outer:meshkit::PathKind::Line;
    path.closed=closed; path.id=i+1; path.marker=i+1;
    for (size_t k=0;k<n;++k) { meshkit::Index v; in>>v; path.vertices.push_back(v); }
    request.paths.push_back(path);
  }
  if (!in) throw std::runtime_error("Incomplete mesh request");
  request.options.maximumSize=std::sqrt(maxArea/.4330127018922193);
  request.options.minimumAngleDegrees=25;
  request.options.cells=meshkit::CellPlan::Triangles;
  request.options.strictSizing=true;
  request.options.limits.maxCells=250000;
  request.options.limits.maxWorkspaceBytes=std::uint64_t(2)<<30;
  meshkit::Providers providers;
  providers.elevation=[](double x,double y){return .02*std::abs(x)+.005*y;};
  providers.identity="runoff-timing/planar-wings-1m2-v1";
  auto result=meshkit::runJob(request,providers);
  if (!result.report.complete() || result.report.sizeConflicts || !result.report.constraintAuditPassed)
    throw std::runtime_error(result.report.code+": "+result.report.message);
  std::ofstream out(argv[2]); out<<std::setprecision(17);
  out<<"{\"maxCellAreaM2\":"<<maxArea<<",\"meshkitVersion\":\""<<result.report.algorithmVersion
     <<"\",\"constraintAuditPassed\":true,\"vertices\":[";
  bool comma=false;
  for (auto v:result.mesh.vertices) {if(comma)out<<',';comma=true;out<<'['<<v.x<<','<<v.y<<','<<v.z<<']';}
  out<<"],\"triangles\":[";comma=false;
  for (auto c:result.mesh.cells) {if(c.count!=3)throw std::runtime_error("Unexpected nontriangle");if(comma)out<<',';comma=true;out<<'['<<c.vertices[0]<<','<<c.vertices[1]<<','<<c.vertices[2]<<']';}
  out<<"]}\n";
  if (!out) throw std::runtime_error("Mesh write failed");
  std::cout<<result.mesh.cells.size()<<" triangles; maximum area "<<maxArea<<" m2\n";
  return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
