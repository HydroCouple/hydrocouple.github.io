import {
  geometry,
  halfWidth,
  bed,
  METHODS,
  stormRates,
  parameters,
  STATIONS,
} from "./model.mjs";
const root = document.getElementById("runoff-explorer");
if (root) initialize();
function initialize() {
  const $ = (id) => root.querySelector(`#rt-${id}`);
  const bundledFiles = globalThis.RUNOFF_FILES;
  async function readJson(file, signal) {
    if (bundledFiles) return JSON.parse(bundledFiles[file.replace(/^\.\//, "")]);
    const response = await fetch(new URL(file, import.meta.url), { signal });
    if (!response.ok) throw new Error(`Could not load ${file}.`);
    return response.json();
  }
  const areaInput = $("area"), ratioInput = $("ratio");
  let storm,
    matrix,
    current,
    view = "flow",
    zoom = false,
    sequence = 0,
    pendingTimer,
    requestController;
  const cache = new Map();

  const format = (n, digits = 1) =>
    new Intl.NumberFormat("en-US", { maximumFractionDigits: digits }).format(n);
  const timeText = (seconds) => {
    const minutes = Math.round(seconds / 60);
    return `${Math.floor(minutes / 60)
      .toString()
      .padStart(2, "0")}:${(minutes % 60)
      .toString()
      .padStart(2, "0")}`;
  };
  const acreFeet = (m3) => m3 / 1233.48183754752;
  const volumeText = (m3) => {
    const digits = acreFeet(m3) < 1 ? 6 : 4;
    return new Intl.NumberFormat("en-US", {
      minimumFractionDigits: digits, maximumFractionDigits: digits,
    }).format(acreFeet(m3));
  };
  const settings = () =>
    parameters({
      areaAcres: (matrix?.areas ?? [0.1,0.3])[Number(areaInput.value)],
      ratio: (matrix?.ratios ?? [0.25, 0.5, 1, 2, 4])[Number(ratioInput.value)],
      resolution: 1,
    });
  const key = (s) => `${s.areaAcres}/${s.ratio}/${s.resolution}`;
  const download = (name, text, type = "text/plain") => {
    const url = URL.createObjectURL(new Blob([text], { type }));
    const link = document.createElement("a");
    link.href = url;
    link.download = name;
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  };
  function refreshGeometry() {
    const s = settings();
    $("area-value").textContent =
      `${format(s.areaAcres, s.areaAcres < 1 ? 3 : 1)} ${s.areaAcres === 1 ? "acre" : "acres"}`;
    $("ratio-value").textContent = s.ratio.toFixed(2);
    areaInput.setAttribute("aria-valuetext", `${s.areaAcres} acres`);
    ratioInput.setAttribute(
      "aria-valuetext",
      `${s.ratio} width divided by length`,
    );
    for (const id of ["book", "drop"]) {
      const g = geometry(s, id);
      drawTerrain($(id), s, id);
      $(`${id}-dim`).textContent =
        `${format(g.width / 0.3048, 0)} ft ${id === "drop" ? "maximum width" : "wide"} × ${format(g.length / 0.3048, 0)} ft long`;
    }
  }
  function changed() {
    clearTimeout(pendingTimer);
    invalidateRequest();
    refreshGeometry();
    $("status").textContent = "Selecting the completed native-model results…";
    for (const id of ["csv", "inp", "rpt"]) $(id).disabled = true;
    if (matrix) pendingTimer = setTimeout(run, 120);
  }
  function invalidateRequest() {
    sequence++;
    requestController?.abort();
    $("progress").style.width = "0%";
  }
  async function run() {
    if (!matrix) return;
    invalidateRequest();
    const selected = settings(),
      found = cache.get(key(selected));
    if (found) {
      show(found);
      return;
    }
    const scenario = matrix.scenarios.find(
      (s) => key(s.settings) === key(selected),
    );
    if (!scenario) {
      failure("This selection is absent from the completed matrix.");
      return;
    }

    for (const id of ["csv", "inp", "rpt"]) $(id).disabled = true;
    $("status").textContent =
      `Loading three completed native runs · ${format(selected.areaAcres)} acres · width/length ${selected.ratio}`;
    if (current)
      $("chart-note").textContent =
        "The displayed curves are from the previous selection while the selected matrix row loads.";
    const token = sequence;
    requestController = new AbortController();
    try {
      const runs = await Promise.all(
        METHODS.map(async (method) => {
          const source = scenario.files[method.id];
          const r = await readJson(source.data, requestController.signal);
          return {
            ...r,
            samples: r.samples.map(([time, flow, volume]) => ({
              time,
              flow,
              volume,
            })),
            inputUrl: source.input,
            reportUrl: source.report,
          };
        }),
      );
      if (token !== sequence) return;
      const result = {
        settings: selected,
        results: runs,
        engine: matrix.engine,
        scenarioId: scenario.id,
        meshes: scenario.meshes,
      };
      cache.set(key(selected), result);
      while (cache.size > 8) cache.delete(cache.keys().next().value);
      show(result);
    } catch (error) {
      if (token === sequence) failure(error.message);
    }
  }
  function failure(message) {
    invalidateRequest();
    $("status").textContent =
      `Results could not load. ${message} Reload the page or choose another completed scenario.`;
  }
  function show(result) {
    current = result;
    $("progress").style.width = "100%";
    for (const id of ["csv", "inp", "rpt"]) $(id).disabled = false;
    const s = result.settings;
    $("status").textContent =
      `Completed · ${format(s.areaAcres)} acres · width/length ${s.ratio.toFixed(2)} · 1 m² baseline mesh · three pregenerated native runs`;
    for (const id of ["book", "drop"]) {
      const m = result.meshes[id];
      const g = geometry(s, id);
      $(`${id}-dim`).textContent = `${format(g.width / 0.3048,0)} ft ${id === "drop" ? "maximum width" : "wide"} × ${format(g.length / 0.3048,0)} ft long · ${format(m.opening_m / 0.3048,2)} ft outlet`;
      $(`${id}-mesh`).textContent = `${format(m.cells,0)} triangular cells · 1 m² maximum allowed. Actual area: ${format(m.cell_area_m2[0],3)}–${format(m.cell_area_m2[1],3)} m²; median ${format(m.median_area_m2,3)} m².`;
    }
    const baseline = result.results.find((r) => r.id === "lumped");
    const meanDelay = (r) => {
      if (r.id === "lumped") return "reference";
      const minutes = (r.centroid - baseline.centroid) / 60;
      return `${minutes > 0 ? "+" : ""}${format(minutes,1)} min vs. SWMM`;
    };
    $("metrics").innerHTML = result.results
      .map(
        (r, i) =>
          `<tr><td><span style="color:${METHODS[i].color}">●</span> ${METHODS[i].label}</td><td><strong>${format(r.peak * 35.3146667, r.peak * 35.3146667 < 1 ? 4 : 2)}</strong></td><td>${timeText(r.peakTime)}</td><td>${r.peakTime > baseline.peakTime ? "+" : ""}${format((r.peakTime - baseline.peakTime) / 60, 0)}</td><td>${timeText(r.centroid)}<small class="rt-timing-delta">${meanDelay(r)}</small></td><td>${timeText(r.crestStart)}–${timeText(r.crestEnd)}</td></tr>`,
      )
      .join("");
    $("volumes").innerHTML = result.results.map((r, i) =>
      `<tr><td><span style="color:${METHODS[i].color}">●</span> ${METHODS[i].label}</td><td>${volumeText(r.totalRain)}</td><td>${volumeText(r.samples.find((p) => p.time === 86400).volume)}</td><td><strong>${volumeText(r.delivered)}</strong></td><td>${format(100 * r.delivered / r.totalRain, 3)}%</td></tr>`,
    ).join("");
    const warnings = [];
    for (let i = 0; i < result.results.length; i++) {
      const r = result.results[i],
        matches = r.continuity_errors_percent.map(Math.abs);
      if (matches.some((e) => e > 1))
        warnings.push(
          `${METHODS[i].label} has a reported continuity error above 1%; inspect its engine report.`,
        );
      if (r.delivered / r.totalRain < 0.95)
        warnings.push(
          `${METHODS[i].label} delivered ${format((100 * r.delivered) / r.totalRain, 1)}% of the rain by hour 48; check final storage and continuity before comparing totals.`,
        );
    }
    if (s.areaAcres >= 1000)
      warnings.push(
        "Uniform NYC point rainfall over this large idealized basin is a sensitivity assumption. No areal reduction or real city drainage network is represented.",
      );
    $("notice").hidden = warnings.length === 0;
    $("notice").textContent = warnings.join(" ");
    chart();
  }
  function chart() {
    const svg = $("chart");
    if (!current) {
      svg.innerHTML =
        '<text x="500" y="180" text-anchor="middle" fill="#5c706d" font-size="18">Loading the completed native-model matrix…</text>';
      return;
    }
    const width = 1000,
      height = 370,
      left = 76,
      right = 25,
      top = 22,
      bottom = 52;
    const peaks = current.results.map((r) => r.peakTime / 3600);
    const lo = zoom ? Math.max(0, Math.min(...peaks) - 1) : 0,
      hi = zoom ? Math.min(48, Math.max(...peaks) + 1) : 48;
    const value = (p) =>
      view === "volume"
        ? (100 * p.volume) / current.results[0].totalRain
        : (p.flow * 35.3146667) /
          (view === "unit" ? current.settings.areaAcres : 1);
    const curves = current.results.map((r) =>
      r.samples.filter((p) => p.time / 3600 >= lo && p.time / 3600 <= hi),
    );
    const rain = stormRates(storm),
      g = geometry(current.settings);
    let rv = 0;
    const rainPoints = [
      { time: 0, flow: (rain[0] / 1000 / 3600) * g.area, volume: 0 },
    ];
    rain.forEach((r, i) => {
      const f = (r / 1000 / 3600) * g.area;
      rainPoints.push({ time: i * 1800, flow: f, volume: rv });
      rv += f * 1800;
      rainPoints.push({ time: (i + 1) * 1800, flow: f, volume: rv });
    });
    rainPoints.push(
      { time: 86400, flow: 0, volume: rv },
      { time: 172800, flow: 0, volume: rv },
    );
    const shownRain = rainPoints.filter(
      (p) => p.time / 3600 >= lo && p.time / 3600 <= hi,
    );
    const max = Math.max(
      1e-8,
      ...curves.flat().map(value),
      ...shownRain.map(value),
    );
    const magnitude = 10 ** Math.floor(Math.log10(max / 4));
    const step = Math.ceil(max / 4 / magnitude) * magnitude;
    const ymax = Math.ceil(max / step) * step;
    const X = (t) => left + ((t - lo) / (hi - lo)) * (width - left - right),
      Y = (q) => height - bottom - (q / ymax) * (height - top - bottom);
    const path = (pts) =>
      pts
        .map(
          (p, i) =>
            `${i ? "L" : "M"}${X(p.time / 3600).toFixed(2)},${Y(value(p)).toFixed(2)}`,
        )
        .join(" ");
    let markup = "";
    for (let i = 0; i <= 5; i++) {
      const y = (ymax * i) / 5;
      markup += `<line x1="${left}" x2="${width - right}" y1="${Y(y)}" y2="${Y(y)}" stroke="#e0e7e2"/><text x="${left - 12}" y="${Y(y) + 4}" text-anchor="end" font-size="13" fill="#5c706d">${format(y, ymax < 1 ? 4 : 2)}</text>`;
    }
    for (let i = 0; i <= 6; i++) {
      const t = lo + ((hi - lo) * i) / 6;
      markup += `<text x="${X(t)}" y="${height - bottom + 26}" text-anchor="middle" font-size="13" fill="#5c706d">${format(t, 1)}</text>`;
    }
    markup += `<path d="${path(shownRain)}" fill="none" stroke="#9ca59d" stroke-width="2" stroke-dasharray="4 5"/>`;
    curves.forEach((curve, i) => {
      markup += `<path d="${path(curve)}" fill="none" stroke="${METHODS[i].color}" stroke-width="2.6" stroke-linejoin="round"/>`;
    });
    markup += `<text x="520" y="365" text-anchor="middle" font-size="13" fill="#5c706d">Hours from storm start</text>`;
    svg.innerHTML = markup;
    $("chart-label").textContent =
      view === "volume"
        ? "Cumulative delivery · % of rainfall"
        : view === "unit"
          ? "Outlet flow · ft³/s per acre"
          : "Outlet flow · ft³/s";
    $("chart-note").textContent =
      `${format(current.settings.areaAcres)} acres · width/length ${current.settings.ratio.toFixed(2)} · one-minute means. ${view === "volume" ? "Dotted line shows cumulative rainfall." : "Dotted line shows rainfall supply."}`;
    $("legend").innerHTML =
      METHODS.map(
        (m) =>
          `<span><i class="rt-swatch" style="border-color:${m.color}"></i>${m.label}</span>`,
      ).join("") +
      '<span><i class="rt-swatch" style="border-color:#9ca59d;border-top-style:dotted"></i>Rainfall</span>';
  }
  areaInput.addEventListener("input", changed);
  ratioInput.addEventListener("input", changed);
  root.querySelectorAll("[data-area]").forEach(
    (b) =>
      (b.onclick = () => {
        areaInput.value = matrix.areas.indexOf(Number(b.dataset.area));
        changed();
      }),
  );
  root.querySelectorAll("[data-ratio]").forEach(
    (b) =>
      (b.onclick = () => {
        ratioInput.value = matrix.ratios.indexOf(Number(b.dataset.ratio));
        changed();
      }),
  );
  root.querySelectorAll("[data-view]").forEach(
    (b) =>
      (b.onclick = () => {
        view = b.dataset.view;
        root
          .querySelectorAll("[data-view]")
          .forEach((x) => x.setAttribute("aria-pressed", String(x === b)));
        chart();
      }),
  );
  $("zoom").onclick = () => {
    zoom = !zoom;
    $("zoom").setAttribute("aria-pressed", String(zoom));
    chart();
  };

  $("csv").onclick = () => {
    if (!current) return;
    const rows = [
      "elapsed_seconds," + METHODS.flatMap((m) => [m.id + "_cfs", m.id + "_cumulative_acft"]).join(","),
    ];
    for (let i = 0; i < current.results[0].samples.length; i++)
      rows.push(
        [
          current.results[0].samples[i].time,
          ...current.results.flatMap((r) => [
            (r.samples[i].flow * 35.3146667).toPrecision(9),
            acreFeet(r.samples[i].volume).toPrecision(12),
          ],
          ),
        ].join(","),
      );
    download(
      `hydrographs-${current.scenarioId}.csv`,
      rows.join("\n") + "\n",
      "text/csv",
    );
  };
  for (const ext of ["inp", "rpt"])
    $(ext).onclick = () => {
      if (!current) return;
      const r = current.results.find((r) => r.id === $("model").value);
      const file = ext === "inp" ? r.inputUrl : r.reportUrl;
      const filename = `${r.id}-${current.scenarioId}.${ext}`;
      if (bundledFiles) {
        download(filename, bundledFiles[file]);
        return;
      }
      const link = document.createElement("a");
      link.href = new URL(file, import.meta.url);
      link.download = filename;
      link.click();
    };
  refreshGeometry();
  chart();
  for (const el of [
    areaInput,
    ratioInput,
    ...root.querySelectorAll("[data-area],[data-ratio]"),
  ])
    el.disabled = true;
  readJson("matrix-index.json")
    .then((index) => {
      if (index.schema_version !== 4)
        throw new Error("The fixed 1 m² baseline results are not available in this copy yet.");
      matrix = index;
      storm = index.storm;
      areaInput.max = String(index.areas.length - 1);
      areaInput.value = "0";
      $("area-end").textContent = format(index.areas.at(-1)) + (index.areas.at(-1) === 1 ? " acre" : " acres");
      $("matrix-summary").textContent = index.areas.length + (index.areas.length === 1 ? " area × " : " areas × ") + index.ratios.length + " shape ratios · " + index.native_instances + " native results";
      for (const el of [areaInput, ratioInput, ...root.querySelectorAll("[data-area],[data-ratio]")]) el.disabled = false;
      for (const button of root.querySelectorAll("[data-area]")) {
        button.hidden = !index.areas.includes(Number(button.dataset.area));
      }
      changed();
    })
    .catch((e) => {
      $("status").textContent =
        `Could not load the completed native matrix. ${e.message}`;
    });
}
function drawTerrain(svg, settings, shape) {
  const g = geometry(settings, shape);
  const scale = 360 / Math.max(g.length, g.width * 1.1),
    zEx = 8;
  const project = (x, y) => [
    265 + scale * (0.85 * x + 0.38 * (y - g.length / 2)),
    235 + scale * (0.24 * x - 0.4 * y - bed(x, y) * zEx),
  ];
  const pt = (x, y) =>
    project(x, y)
      .map((v) => v.toFixed(1))
      .join(",");
  const marker = `arrow-${shape}`;
  let html = `<defs><marker id="${marker}" markerWidth="5" markerHeight="5" refX="4" refY="2.5" orient="auto"><path d="M0 0 L5 2.5 L0 5 Z" fill="#087f78"/></marker></defs>`;
  const levels = shape === "drop" ? STATIONS : Array.from({length:13}, (_,i) => i/12);
  for (let j = levels.length - 2; j >= 0; j--) {
    const y0 = levels[j] * g.length,
      y1 = levels[j+1] * g.length,
      h0 = halfWidth(levels[j], g.width, shape),
      h1 = halfWidth(levels[j+1], g.width, shape);
    for (const sign of [-1, 1])
      html += `<polygon points="${pt(0, y0)} ${pt(sign * h0, y0)} ${pt(sign * h1, y1)} ${pt(0, y1)}" fill="${sign < 0 ? "#dce9d9" : "#c4d9cc"}" stroke="#a5bfb0" stroke-width=".6"/>`;
  }
  html += `<path d="M${pt(0, g.length)} L${pt(0, 0)}" stroke="#306f68" stroke-width="3.2"/>`;
  for (const f of [0.3, 0.58, 0.84]) {
    const y = f * g.length,
      h = halfWidth(f, g.width, shape);
    for (const sign of [-1, 1])
      html += `<path d="M${pt(sign * h * 0.82, y)} L${pt(sign * h * 0.08, y - g.length * 0.06)}" fill="none" stroke="#087f78" stroke-width="1.8" marker-end="url(#${marker})"/>`;
  }
  html += `<path d="M${pt(0, g.length * 0.4)} L${pt(0, g.length * 0.08)}" stroke="#087f78" stroke-width="2.6" marker-end="url(#${marker})"/>`;
  const outlet = project(0, 0);
  html += `<circle cx="${outlet[0]}" cy="${outlet[1]}" r="4" fill="#173c3a"/><text x="${outlet[0]}" y="${outlet[1] + 22}" text-anchor="middle" fill="#365650" font-size="13">Outlet</text>`;
  svg.innerHTML = html;
}
