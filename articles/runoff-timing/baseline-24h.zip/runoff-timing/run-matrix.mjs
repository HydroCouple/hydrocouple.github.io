// Offline orchestration of independent native engine processes. No Python or npm dependencies.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
const here=path.dirname(fileURLToPath(import.meta.url));
const arg=(key,fallback)=>process.argv.includes(key)?process.argv[process.argv.indexOf(key)+1]:fallback;
const engine=arg('--engine',process.env.RUNOFF_ENGINE),runner=arg('--runner',process.env.RUNOFF_RUNNER);
if(!engine||!runner)throw Error('Supply --engine and --runner native paths');
const digest=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const engineHash=digest(engine),runnerHash=digest(runner);
const plan=JSON.parse(fs.readFileSync(path.join(here,'matrix-plan.json')));
const selectedAreas=arg('--areas')?.split(',').map(Number);
const jobs=plan.scenarios.flatMap(s=>plan.methods.map(m=>({s,m}))).filter(({s,m})=>(!selectedAreas||selectedAreas.includes(s.settings.areaAcres))&&(!arg('--scenario')||s.id===arg('--scenario'))&&(!arg('--method')||m.id===arg('--method')));
let next=0,done=0;const failures=[];
async function execute({s,m}) {
 const directory=path.join(here,'matrix',s.id),input=path.join(directory,m.id+'.inp'),output=path.join(directory,m.id+'.json'),report=path.join(directory,m.id+'.rpt');
 const identity={engine_sha256:engineHash,input_sha256:digest(input)};
 if(fs.existsSync(output)){const old=JSON.parse(fs.readFileSync(output));if(JSON.stringify(old.identity)===JSON.stringify(identity)&&old.samples?.length===2881){console.log(`${s.id} ${m.id}: cached`);return;}}
 const lock=path.join(directory,m.id+'.lock'),fd=fs.openSync(lock,'wx');fs.writeSync(fd,String(process.pid));fs.closeSync(fd);
 const temporary=output+'.tmp';
 try {
  console.log(`${s.id} ${m.id}: started`);
  await new Promise((resolve,reject)=>{
   const child=spawn(runner,[engine,input,report,temporary,m.id,String(s.settings.areaAcres),String(plan.storm.frequency.depth_inches)],{stdio:['ignore','pipe','pipe']});
   let error='';child.stdout.on('data',data=>{for(const line of data.toString().trim().split('\n'))console.log(`${s.id} ${m.id}: ${line}`);});
   child.stderr.on('data',data=>{error+=data;});child.on('error',reject);child.on('exit',code=>code===0?resolve():reject(Error(error||`Native process exited ${code}`)));
  });
  const result=JSON.parse(fs.readFileSync(temporary));result.identity=identity;result.runner_sha256=runnerHash;
  result.input_file=m.id+'.inp';result.report_file=m.id+'.rpt';result.centroid_definition='Flow-weighted interval midpoint, seconds since start';
  fs.writeFileSync(temporary,JSON.stringify(result));fs.renameSync(temporary,output);
  console.log(`${s.id} ${m.id}: complete in ${result.wall_seconds.toFixed(1)} s`);
 }finally{fs.unlinkSync(lock);}
}
async function worker(){while(next<jobs.length){const job=jobs[next++];try{await execute(job);}catch(e){failures.push({scenario:job.s.id,method:job.m.id,error:e.message});console.error(e);}done++;}}
await Promise.all(Array.from({length:Number(arg('--workers','3'))},worker));
if(failures.length){fs.writeFileSync(path.join(here,'matrix-failures.json'),JSON.stringify(failures,null,2));process.exitCode=1;}
console.log(`Finished ${done} records; ${failures.length} failures.`);
