// Verification of executed baseline inputs/results and the static article.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {here,digest,parseInput,meshInfo} from './package-matrix.mjs';
import {geometry,buildModel,stormRates,bed,ACRE_M2,METHODS} from './model.mjs';
const read=f=>JSON.parse(fs.readFileSync(path.join(here,f)));
const storm=read('storm.json'),index=read('matrix-index.json');
assert.equal(index.schema_version,4);
assert.deepEqual(METHODS.map(m=>m.id),['lumped','book','drop']);
assert.equal(index.scenarios.length,index.areas.length*index.ratios.length);
assert.equal(index.native_instances,index.scenarios.length*3);
assert(Math.abs(stormRates(storm).reduce((a,b)=>a+b,0)/2-6.77*25.4)<1e-10);
for(const scenario of index.scenarios)for(const method of METHODS){
 const files=scenario.files[method.id];
 for(const kind of ['input','report','data'])assert.equal(digest(path.join(here,files[kind])),files[kind+'_sha256']);
 const mesh=method.id==='lumped'?null:read(`matrix/${scenario.id}/${method.id}.mesh.json`);
 const generated=buildModel(scenario.settings,method.id,storm,mesh),input=fs.readFileSync(path.join(here,files.input),'utf8');
 assert.equal(generated,input);const d=parseInput(input),r=read(files.data);
 assert.equal(r.identity.engine_sha256,index.engine_sha256);assert.equal(r.samples.length,2881);assert(r.peak>0);
 r.samples.forEach((row,i)=>{assert.equal(row[0],i*60);assert(row.every(Number.isFinite));assert(row[1]>=0);});
 for(const end of [1440,2880])assert(Math.abs(r.samples.slice(0,end+1).reduce((v,row)=>v+row[1]*60,0)-r.samples[end][2])<r.totalRain*1e-7);
 assert(Math.abs(r.totalRain/1233.48183754752-scenario.settings.areaAcres*6.77/12)<1e-8);
 assert.equal(d.TIMESERIES.length,49);
 if(!mesh){assert.equal(d.SUBCATCHMENTS.length,1);assert(Math.abs(Number(d.SUBCATCHMENTS[0][3])*10000-scenario.settings.areaAcres*ACRE_M2)<1e-6);continue;}
 const m=meshInfo(input);assert.deepEqual(m,scenario.meshes[method.id]);assert(m.cell_area_m2[1]<=1+1e-7);
 const g=geometry(scenario.settings,method.id);assert(Math.abs(m.area_m2-g.area)/g.area<1e-9);
 assert(Math.abs(m.opening_m/(g.width*(method.id==='drop'?.05:1))-.25)<1e-8);
 // The exact central fold must be represented by mesh edges, not averaged through cells.
 for(const [x,y,z] of mesh.vertices)assert(Math.abs(z-bed(x,y))<1e-10);
 for(const cell of mesh.triangles){const xs=cell.map(i=>mesh.vertices[i][0]);assert(Math.min(...xs)>-1e-9 || Math.max(...xs)<1e-9);}
 assert(Math.abs(r.balance.rainfallIn-r.totalRain)/r.totalRain<1e-8);
}
const page=fs.readFileSync(path.join(here,'../../articles.html'),'utf8'),ui=fs.readFileSync(path.join(here,'explorer.mjs'),'utf8');
assert(!page.includes('id="uk-2d-benchmark-assessment"'));assert.equal([...page.matchAll(/id="runoff-timing"/g)].length,1);
assert(page.includes('id="rt-volumes"'));assert(!page.includes('value="routed"'));assert(!page.includes('id="rt-grid"'));
assert(!ui.includes('new Worker')&&!ui.includes('runComparison'));
assert(page.includes('<script defer src="articles/runoff-timing/explorer.js"></script>'));
assert(!fs.readFileSync(path.join(here,'explorer.js'),'utf8').includes('import.meta'));
console.log(`PASS: ${index.native_instances} actual native records; common 1 m² cell-area cap; exact basin/outlet/fold geometry; 24/48-hour volumes; static three-model article.`);
