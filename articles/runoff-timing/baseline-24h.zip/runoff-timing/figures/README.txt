LINKEDIN FIGURES

Upload the numbered PNG files in article order. Figures 1–4 are 2400 pixels wide, with editable SVG originals. Figure 5 is the preserved 1819-pixel-wide historical image; it uses different forcing, geometry and numerical settings. No simulation has been rerun.

linkedin-01-representations.png
Figure 1. Three representations of the same 0.1-acre elongated basin. SWMM uses equivalent width W = 2L; the 2D models resolve the side slopes and central valley. The teardrop has a narrower outlet, which is part of the comparison. Terrain lines are schematic; elevation is exaggerated eightfold.
Alt text: SWMM nonlinear storage beside open-book and teardrop terrains, with arrows toward the central valley and outlet.

linkedin-02-hydrographs.png
Figure 2. Native outlet hydrographs for the 0.1-acre elongated case. The right panel enlarges both the time window and vertical scale. The open book peaks earlier while its flow-weighted mean arrival is later. The mean uses all 48 hours, including recession; plotted flows are one-minute means.
Alt text: Native hydrographs for a 0.1-acre elongated basin: full rainfall period, enlarged peak detail and timing metrics.

linkedin-03-arrival-time.png
Figure 3. Mean arrival time relative to lumped SWMM across all ten geometries. Positive values mean later arrival. Narrow basins and wide basins give different directions of change under this forcing and width convention. Every bar represents a completed simulation.
Alt text: Mean arrival differences relative to SWMM for five aspect ratios at 0.1 and 0.3 acres, with positive and negative bars.

linkedin-04-volumes.png
Figure 4. Native cumulative outlet volumes for elongated basins at both simulated areas. Rainfall is identical across methods at each area. Differences at a fixed cutoff include remaining storage and numerical balance error. Volumes are in acre-feet and rounded to six decimals.
Alt text: Native rainfall and runoff volume table for 0.1- and 0.3-acre elongated basins, showing 24-hour and 48-hour discharge.

linkedin-05-earlier-example.png
Figure 5. The earlier 64-acre diagnostic example, preserved for context. Both shapes in this figure receive the same 3-inch Type II storm. Elongation increases flow distance across the fold. These are local-inertial runs with different meshes, collectors and numerical settings from the current baseline. The earlier report records significant mesh/time-step sensitivity, so its exact peaks are not a converged benchmark. Figures 1–4 do not reproduce this experiment.
Alt text: Earlier 64-acre elongated and square basins under the same 3-inch Type II storm, with much more distinct receiving-node hydrographs.
