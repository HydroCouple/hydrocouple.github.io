// Execute one actual native OpenSWMM instance and extract cumulative outlet volumes.
#include <dlfcn.h>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <regex>
#include <array>
#include <vector>
#include <cmath>
#include <chrono>
#include <stdexcept>
#include <algorithm>
template<class T> T symbol(void* library,const char* name) {
  auto p=dlsym(library,name);if(!p)throw std::runtime_error(std::string("Missing native symbol: ")+name);return reinterpret_cast<T>(p);
}
int main(int argc,char** argv) {try {
  if(argc!=8)throw std::runtime_error("native-runner engine input report output method area_acres depth_inches");
  const bool surface=std::string(argv[5])!="lumped";
  const double rain=std::stod(argv[6])*4046.8564224*std::stod(argv[7])*.0254;
  auto began=std::chrono::steady_clock::now();
  void* lib=dlopen(argv[1],RTLD_NOW|RTLD_LOCAL);if(!lib)throw std::runtime_error(dlerror());
  auto create=symbol<void*(*)()>(lib,"swmm_engine_create");
  auto destroy=symbol<void(*)(void*)>(lib,"swmm_engine_destroy");
  auto open=symbol<int(*)(void*,const char*,const char*,const char*,const char*)>(lib,"swmm_engine_open");
  auto initialize=symbol<int(*)(void*)>(lib,"swmm_engine_initialize");
  auto start=symbol<int(*)(void*,int)>(lib,"swmm_engine_start");
  auto step=symbol<int(*)(void*,double*)>(lib,"swmm_engine_step");
  auto getElapsed=symbol<int(*)(void*,double*)>(lib,"swmm_engine_get_elapsed_seconds");
  auto end=symbol<int(*)(void*)>(lib,"swmm_engine_end");
  auto report=symbol<int(*)(void*)>(lib,"swmm_engine_report");
  auto close=symbol<int(*)(void*)>(lib,"swmm_engine_close");
  auto error=symbol<const char*(*)(void*)>(lib,"swmm_get_last_error_msg");
  auto routing=symbol<int(*)(void*,int,double*)>(lib,"swmm_get_routing_total");
  auto balance=symbol<int(*)(void*,double*,double*,double*,double*,double*,double*,double*,double*,double*,double*)>(lib,"swmm_2d_get_mass_balance");
  auto continuity=symbol<int(*)(void*,double*)>(lib,"swmm_2d_get_continuity_error");
  void* engine=create();if(!engine)throw std::runtime_error("Engine allocation failed");
  auto check=[&](int rc){if(rc)throw std::runtime_error(error(engine)?error(engine):"Native engine error");};
  check(open(engine,argv[2],argv[3],nullptr,nullptr));check(initialize(engine));check(start(engine,0));
  std::vector<std::array<double,3>> samples{{0,0,0}};
  double elapsed=0,lastTime=0,volume=0,sampleVolume=0;int nextSample=60,steps=0,nextProgress=21600;
  do {
    check(step(engine,&elapsed));++steps;
    double now=elapsed*86400;if(elapsed<=0)check(getElapsed(engine,&now));
    double before=volume;
    if(surface)check(balance(engine,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,nullptr,&volume,nullptr));
    else{check(routing(engine,6,&volume));volume*=.028316846592;}
    while(now+1e-6>=nextSample && nextSample<=172800) {
      double f=now>lastTime?(nextSample-lastTime)/(now-lastTime):1;
      double cumulative=before+(volume-before)*f;
      samples.push_back({double(nextSample),std::max(0.,(cumulative-sampleVolume)/60),cumulative});
      sampleVolume=cumulative;nextSample+=60;
    }
    lastTime=now;
    if(now>=nextProgress){std::cout<<"simulated "<<now/3600<<" h"<<std::endl;nextProgress+=21600;}
  }while(elapsed>0);
  check(end(engine));
  double b[10]{},ce=0;
  if(surface){check(balance(engine,&b[0],&b[1],&b[2],&b[3],&b[4],&b[5],&b[6],&b[7],&b[8],&b[9]));check(continuity(engine,&ce));}
  check(report(engine));check(close(engine));destroy(engine);dlclose(lib);
  if(samples.size()!=2881 || std::abs(lastTime-172800)>1e-5)throw std::runtime_error("Incomplete native run");
  double peak=0,peakTime=0,crestStart=-1,crestEnd=0,weighted=0,qsum=0;
  for(auto row:samples){for(auto v:row)if(!std::isfinite(v))throw std::runtime_error("Nonfinite result");if(row[1]>peak){peak=row[1];peakTime=row[0];}weighted+=(row[0]-30)*row[1];qsum+=row[1];}
  if(peak<=0)throw std::runtime_error("No runoff");
  for(auto row:samples)if(row[1]>=.95*peak){if(crestStart<0)crestStart=row[0];crestEnd=row[0];}
  std::ifstream rf(argv[3]);std::ostringstream rs;rs<<rf.rdbuf();const std::string rpt=rs.str();
  if(std::regex_search(rpt,std::regex("ERROR\\s+[0-9]+")))throw std::runtime_error("Error in report");
  std::regex re("Continuity Error \\(%\\)[^\\n]*?([-0-9.]+)\\s*(?:\\n|$)");
  std::vector<double> errors;for(std::sregex_iterator it(rpt.begin(),rpt.end(),re),e;it!=e;++it)errors.push_back(std::stod((*it)[1]));
  if(errors.empty())throw std::runtime_error("Missing continuity summary");
  std::ofstream out(argv[4]);out<<std::setprecision(17);
  out<<"{\"id\":\""<<argv[5]<<"\",\"sampling\":\"native_outlet_ledger_v3\",\"samples\":[";
  bool comma=false;for(auto row:samples){if(comma)out<<',';comma=true;out<<'['<<row[0]<<','<<row[1]<<','<<row[2]<<']';}
  out<<"],\"peak\":"<<peak<<",\"peakTime\":"<<peakTime<<",\"crestStart\":"<<crestStart<<",\"crestEnd\":"<<crestEnd
     <<",\"centroid\":"<<weighted/qsum<<",\"totalRain\":"<<rain<<",\"delivered\":"<<volume<<",\"balance\":";
  const char* keys[]={"initStorage","finalStorage","rainfallIn","coupling1dTo2dIn","coupling2dTo1dOut","outfallIn","outfallOut","boundaryIn","boundaryOut","evapOut"};
  if(surface){out<<'{';for(int i=0;i<10;++i){if(i)out<<',';out<<'\"'<<keys[i]<<"\":"<<b[i];}out<<",\"continuityError\":"<<ce<<'}';}else out<<"null";
  out<<",\"continuity_errors_percent\":[";for(size_t i=0;i<errors.size();++i){if(i)out<<',';out<<errors[i];}
  const double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-began).count();
  out<<"],\"wall_seconds\":"<<seconds<<",\"routing_steps\":"<<steps<<"}\n";
  if(!out)throw std::runtime_error("Output write failed");
  return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}}
