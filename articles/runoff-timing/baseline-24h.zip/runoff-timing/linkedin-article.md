# Does a spatial runoff model necessarily peak later?

Caleb Buahin · November 6, 2026

A lumped SWMM subcatchment and a 2D terrain model represent the route to an outlet differently. That gives us a hypothesis to test: how much does the representation change peak timing, attenuation and the rest of the hydrograph?

It does not guarantee a large shift in the time of maximum. Storm duration, the shape of the rainfall crest, surface storage and the distribution of flow paths all matter.

The figures below first examine a **0.1–0.3-acre baseline**. They do not repeat the earlier 4- and 64-acre diagnostic models. Figure 5 preserves that earlier comparison and explains why its larger differences should not be expected to reappear automatically here.

## Three representations, one forcing

I built an interactive comparison of a single SWMM subcatchment, a 2D open-book basin and a 2D teardrop basin. The controls select completed native OpenSWMM simulations by area and width-to-length ratio. The browser displays the saved outputs directly, without interpolating between scenarios.

The open book has two side slopes feeding a central valley that descends toward the outlet. The teardrop changes the contributing width along that route. Both have the same area, bounding aspect ratio, side slope, center slope and roughness. The teardrop has a narrower toe, so opening the central quarter of each downstream edge also gives it a narrower outlet. That outlet difference is part of this experiment.

![SWMM nonlinear storage beside open-book and teardrop terrains, with arrows toward the central valley and outlet.](figures/linkedin-01-representations.png)

*Figure 1. Three representations of the same 0.1-acre elongated basin. SWMM uses equivalent width W = 2L; the 2D models resolve the side slopes and central valley. The teardrop has a narrower outlet, which is part of the comparison. Terrain lines are schematic; elevation is exaggerated eightfold.*

SWMM represents its subcatchment as a nonlinear reservoir. Rain changes the stored surface depth, and a Manning relation controls discharge. Its width-to-area ratio affects the response. A 2D solver resolves spatial flow and convergence on the terrain. Neither representation guarantees a particular peak delay relative to the other. [EPA SWMM Hydrology Reference Manual, chapter 3](https://nepis.epa.gov/Exe/ZyPURL.cgi?Dockey=P100NYRA.TXT).

The common forcing is NOAA Atlas 14's New York City **25-year, 24-hour point depth of 6.77 inches**, distributed using the Area 2 second-quartile median temporal pattern. Its highest 30-minute intensity falls between hours 10 and 10.5. The temporal pattern is an explicit modeling choice; the frequency designation belongs to the 24-hour depth. [NOAA point-frequency data](https://hdsc.nws.noaa.gov/cgi-bin/new/cgi_readH5.py?lat=40.7128&lon=-74.0060&type=pf&data=depth&units=english&series=pds), [NOAA temporal distributions](https://hdsc.nws.noaa.gov/pub/hdsc/data/ne/ne_2_24h_temporal.csv).

All models start dry and use zero infiltration, evaporation and depression storage. They run for 48 hours, allowing another day of drainage after the storm ends.

## Match physical resolution

Using the same number of cells does not give different basin shapes the same physical resolution. I replaced that approach with one common **1 m² maximum triangular-cell area** for both 2D shapes, using the same mesher quality setting and solver options. Boundary cells can be smaller. The article displays their actual area range and median.

This is a selected baseline, without a mesh-convergence series. The local batch covers **0.1 and 0.3 acres**, with five width-to-length ratios at each area. Run time limits its extent. Large basins are not silently assigned coarser cells: 64 acres already requires at least about 259,000 cells at this resolution, and 100,000 acres about 405 million before additional boundary refinement. These small-basin results do not establish a size threshold for using SWMM or predict city-scale behavior.

## Look beyond a single timestamp

A broad rainfall crest can let small basins approach the rainfall supply rate before it declines. Different hydrographs may therefore reach their maxima during the same rainfall block. Rain also falls close to the outlet; a 2D model does not delay every drop by the basin's longest travel time.

One example illustrates the distinction. At 0.1 acre and a width-to-length ratio of 0.25, the 2D open book peaks ten minutes before lumped SWMM, while its flow-weighted mean arrival is **3.4 minutes later**. Their peak flows differ by just 0.006%. The teardrop peaks at the same reported time as SWMM, while its mean arrival is **5.1 minutes later**. On a nearly flat crest, the time of the highest computed flow does not describe the timing of the whole hydrograph.

![Native hydrographs for a 0.1-acre elongated basin: full rainfall period, enlarged peak detail and timing metrics.](figures/linkedin-02-hydrographs.png)

*Figure 2. Native outlet hydrographs for the 0.1-acre elongated case. The right panel enlarges both the time window and vertical scale. The open book peaks earlier while its flow-weighted mean arrival is later. The mean uses all 48 hours, including recession; plotted flows are one-minute means.*

The direction also changes with shape. In the 0.3-acre wide case, the open book’s mean arrival is 4.7 minutes earlier than SWMM, and the teardrop’s is 4.2 minutes earlier. The chosen width convention, geometry and forcing all affect the comparison.

![Mean arrival differences relative to SWMM for five aspect ratios at 0.1 and 0.3 acres, with positive and negative bars.](figures/linkedin-03-arrival-time.png)

*Figure 3. Mean arrival time relative to lumped SWMM across all ten geometries. Positive values mean later arrival. Narrow basins and wide basins give different directions of change under this forcing and width convention. Every bar represents a completed simulation.*

The article compares peak flow, peak delay relative to SWMM, the interval within 5% of peak and flow-weighted mean arrival time. That last measure uses the full hydrograph discharged during the 48-hour window, including the recession.

It also compares actual runoff volumes at 24 and 48 hours in acre-feet. With no losses, eventual runoff should approach the same rainfall volume. Differences at a fixed cutoff show delayed delivery, remaining storage and numerical balance residuals; they are not automatically differences in total runoff production.

![Native rainfall and runoff volume table for 0.1- and 0.3-acre elongated basins, showing 24-hour and 48-hour discharge.](figures/linkedin-04-volumes.png)

*Figure 4. Native cumulative outlet volumes for elongated basins at both simulated areas. Rainfall is identical across methods at each area. Differences at a fixed cutoff include remaining storage and numerical balance error. Volumes are in acre-feet and rounded to six decimals.*

## Why the first example looked different

The earlier models did show substantial differences. In the saved 64-acre elongated run, SWMM peaked at **131.26 ft³/s at 12:00**, while 2D peaked at **114.64 ft³/s at 12:09**. At 12:10, their flows were **89.51 and 114.62 ft³/s**, respectively. At four acres with a 792-ft sheet-flow path, the peaks were **13.15 and 11.55 ft³/s**; both occurred at noon, but ten minutes later the flows were **4.98 and 8.81 ft³/s**.

The two methods shared the same rainfall within that earlier experiment. The current experiment uses a different forcing: the original was an illustrative **3-inch Type II storm**, with a **3.672 in/h** burst from 11:45 to 12:00 and no assigned return period. The NYC design storm totals **6.77 inches**, but its peak half-hour intensity is only **0.69731 in/h**. It has more total rain and a much broader, lower crest.

The direction of elongation also changed. The original long rectangles stretched **across the fold**, producing sheet-flow paths of **792 ft at four acres** and **3,168 ft at 64 acres**. The current width/length = 0.25 cases stretch **along the valley**. Their lateral sheet-flow paths are only **16.5 ft at 0.1 acre** and **28.6 ft at 0.3 acre**. The earlier collector transferred water along the whole fold to a receiving node; the current 2D surfaces route along a sloping valley to a downstream opening. These are different hydraulic experiments.

![Earlier 64-acre elongated and square basins under the same 3-inch Type II storm, with much more distinct receiving-node hydrographs.](figures/linkedin-05-earlier-example.png)

*Figure 5. The earlier 64-acre diagnostic example, preserved for context. Both shapes in this figure receive the same 3-inch Type II storm. Elongation increases flow distance across the fold. These are local-inertial runs with different meshes, collectors and numerical settings from the current baseline. The earlier report records significant mesh/time-step sensitivity, so its exact peaks are not a converged benchmark. Figures 1–4 do not reproduce this experiment.*

Other settings changed too: side slope increased from 1% to 2%, Manning’s n from 0.016 to 0.030, and the 2D formulation changed from local-inertial to full shallow-water equations. The original results used one-minute node-flow samples; the current curves use one-minute mean outlet flows. The earlier report also documented sensitivity of the 64-acre 2D peak time to mesh and time step, including 12:09 versus 12:35. The larger earlier differences therefore cannot all be assigned to physical routing alone.

A later, intermediate version already used the exact same NYC rainfall as the current article, but still included 64-acre and city-scale cases. Its exploratory 64-acre elongated case had mean arrival delays of 15.5 minutes for the open book and 23.8 minutes for the teardrop relative to SWMM. Those larger cases were excluded when the common 1 m² mesh was adopted and the batch was reduced to 0.1–0.3 acres. They used scaled meshes with fixed cell counts, so their exact values remain exploratory; the current figures omit that part of the area range entirely.

Limiting the current batch to 0.1–0.3 acres removed the long-flow-path and large-area stress tests. Near-coincident peaks in this small-basin matrix do **not** refute the earlier observations or answer the original larger-sewershed question. A controlled comparison would hold the storm, area, slopes, roughness, width convention and outlet collection fixed while changing the runoff representation. [Input and result audit](https://www.hydrocouple.org/articles/runoff-timing/evidence/experiment-history.json).

## Make the calculation inspectable

Each curve comes from an actual native OpenSWMM instance. The input, engine report, hydrograph and cumulative volumes can be downloaded. Mesh generation and model execution happen offline. The published article is ordinary static HTML and JavaScript that works on GitHub Pages, with no Python or hydraulic solver running on the website.

The useful outcome is to see when spatial routing changes the response materially, and when the storm makes different representations appear similar. The experiment reports those outcomes rather than requiring a large timing difference in advance.

[Explore the interactive article and download the models](https://www.hydrocouple.org/articles/runoff-timing/).
