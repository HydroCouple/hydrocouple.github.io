// Offline input preparation with the native MeshKit adapter. No Python.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
import {buildModel,METHODS,geometry,halfWidth,STATIONS} from './model.mjs';
const here=path.dirname(fileURLToPath(import.meta.url));
const arg=(name,fallback)=>process.argv.includes(name)?process.argv[process.argv.indexOf(name)+1]:fallback;
const mesher=arg('--mesher',process.env.RUNOFF_MESHER);
if(!mesher) throw Error('Supply --mesher /path/to/native-mesh');
const areas=arg('--areas','0.1').split(',').map(Number);
const ratios=[0.25,0.5,1,2,4],storm=JSON.parse(fs.readFileSync(path.join(here,'storm.json')));
const scenarios=[];
for(const areaAcres of areas) for(const ratio of ratios) {
 const settings={areaAcres,ratio,resolution:1,maxCellAreaM2:1};
 const id=`a${areaAcres}-r${ratio}-m1`,directory=path.join(here,'matrix',id);
 fs.mkdirSync(directory,{recursive:true});
 for(const method of METHODS) {
  let mesh=null;
  if(method.id!=='lumped') {
   const g=geometry(settings,method.id),toe=halfWidth(0,g.width,method.id);
   const points=[[-toe,0],[-toe/4,0],[0,0],[toe/4,0],[toe,0]];
   const stations=method.id==='drop'?STATIONS:[0,1];
   for(const f of stations.slice(1)) points.push([halfWidth(f,g.width,method.id),f*g.length]);
   const top=points.length;points.push([0,g.length]);
   for(const f of stations.slice(1).reverse())points.push([-halfWidth(f,g.width,method.id),f*g.length]);
   const request=[`${points.length} 2 1`,...points.map(p=>p.join(' ')),`0 1 ${points.length} ${points.map((_,i)=>i).join(' ')}`,`1 0 2 2 ${top}`].join('\n')+'\n';
   const req=path.join(directory,method.id+'.mesh-request.txt'),out=path.join(directory,method.id+'.mesh.json');
   if(!fs.existsSync(out)||!fs.existsSync(req)||fs.readFileSync(req,'utf8')!==request) {
    fs.writeFileSync(req,request);process.stdout.write(`${id} ${method.id}: `);execFileSync(mesher,[req,out],{stdio:'inherit'});
   }
   mesh=JSON.parse(fs.readFileSync(out));
  }
  fs.writeFileSync(path.join(directory,method.id+'.inp'),buildModel(settings,method.id,storm,mesh));
 }
 scenarios.push({id,settings});
}
fs.writeFileSync(path.join(here,'matrix-plan.json'),JSON.stringify({areas,ratios,scenarios,methods:METHODS,storm,meshPolicy:'Fixed 1 m² maximum triangle area; one baseline, no convergence runs'},null,2));
console.log(`${scenarios.length} baseline geometries / ${scenarios.length*METHODS.length} native model records`);
